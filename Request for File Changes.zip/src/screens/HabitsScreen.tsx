import { useState } from 'react';
import { useApp, getTodayStr, calculateCurrentStreak, calculateLongestStreak } from '../store';
import { CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { Habit } from '../types';
import CreateHabitModal from '../components/CreateHabitModal';
import { LogoMark } from '../components/AppLogo';

export default function HabitsScreen() {
  const { currentUser, habits, completions, deleteHabit, completeHabit, showToast, setEditingHabit } = useApp();
  const [showCreate, setShowCreate] = useState(false);
  const [editingHabit, setLocalEditingHabit] = useState<Habit | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  if (!currentUser) return null;

  const today = getTodayStr();
  const userHabits = habits.filter(h => h.userId === currentUser.id);

  const filtered = userHabits.filter(h => {
    if (filter === 'active') return h.active;
    if (filter === 'completed') {
      return completions.some(c => c.habitId === h.id && c.date === today && c.completed);
    }
    return true;
  });

  function handleDelete(id: string) {
    setDeletingId(id);
  }

  function confirmDelete(id: string) {
    deleteHabit(id);
    setDeletingId(null);
    showToast('Habit deleted.', 'info');
  }

  function handleComplete(habitId: string) {
    const success = completeHabit(habitId, today);
    if (success) {
      showToast('Great job! Habit completed successfully. ❤️', 'success');
    } else {
      showToast('Already completed today!', 'info');
    }
  }

  function handleEdit(habit: Habit) {
    setLocalEditingHabit(habit);
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, var(--secondary) 0%, #2D6E3E 100%)' }}>
        <div className="max-w-sm mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-white opacity-70 mb-0.5">All Habits</p>
              <h1 className="font-display font-bold text-2xl text-white">My Habits</h1>
            </div>
            <button
              onClick={() => setShowCreate(true)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold"
              style={{ background: 'rgba(255,255,255,0.2)', color: '#fff' }}
            >
              +
            </button>
          </div>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Filter tabs */}
        <div className="flex gap-2 mt-4 mb-4">
          {(['all', 'active', 'completed'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="flex-1 py-2 rounded-xl text-xs font-semibold capitalize transition-all"
              style={{
                background: filter === f ? 'var(--primary)' : 'var(--muted)',
                color: filter === f ? 'var(--primary-foreground)' : 'var(--muted-foreground)',
              }}
            >
              {f}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16 rounded-2xl mt-4" style={{ background: 'var(--muted)' }}>
            <div className="text-5xl mb-3">🌱</div>
            <p className="font-medium" style={{ color: 'var(--foreground)' }}>
              {filter === 'all' ? 'No habits yet. Create your first habit! 🎯' : 'No habits in this category'}
            </p>
            {filter === 'all' && (
              <button
                onClick={() => setShowCreate(true)}
                className="mt-4 px-5 py-2.5 rounded-xl text-sm font-semibold"
                style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
              >
                Create Habit
              </button>
            )}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map(habit => {
              const done = completions.some(c => c.habitId === habit.id && c.date === today && c.completed);
              const currentStreak = calculateCurrentStreak(habit.id, completions);
              const longestStreak = calculateLongestStreak(habit.id, completions);
              const color = CATEGORY_COLORS[habit.category];

              return (
                <div
                  key={habit.id}
                  className="rounded-2xl p-4 shadow-sm"
                  style={{
                    background: 'var(--card)',
                    border: `1.5px solid ${done ? color + '40' : 'var(--border)'}`,
                  }}
                >
                  {/* Top row */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-none text-lg"
                      style={{ background: color + '20' }}>
                      {CATEGORY_ICONS[habit.category]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm" style={{ color: 'var(--foreground)' }}>
                        {habit.name}
                      </p>
                      <p className="text-xs mt-0.5" style={{ color: color }}>
                        {habit.category} · {habit.frequency}
                      </p>
                    </div>
                    {done && (
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: color + '20', color }}>
                        Done ✓
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  {habit.description && (
                    <p className="text-xs mb-2 leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                      {habit.description}
                    </p>
                  )}
                  <p className="text-xs mb-3" style={{ color: 'var(--foreground)' }}>
                    🎯 <span style={{ color: 'var(--muted-foreground)' }}>Target:</span> {habit.target}
                  </p>

                  {/* Streak info */}
                  <div className="flex gap-3 mb-3">
                    <div className="flex items-center gap-1">
                      <span className="text-sm">🔥</span>
                      <span className="text-xs font-medium" style={{ color: 'var(--accent)' }}>
                        {currentStreak} day streak
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-sm">🏆</span>
                      <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                        Best: {longestStreak}
                      </span>
                    </div>
                    {habit.reminderEnabled && (
                      <div className="flex items-center gap-1">
                        <span className="text-sm">🔔</span>
                        <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                          {habit.reminderTime}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2" style={{ borderTop: '1px solid var(--border)' }}>
                    <button
                      onClick={() => handleComplete(habit.id)}
                      disabled={done}
                      className="flex-1 py-2 rounded-xl text-xs font-semibold transition-all"
                      style={{
                        background: done ? 'var(--muted)' : color,
                        color: done ? 'var(--muted-foreground)' : '#fff',
                      }}
                    >
                      {done ? '✓ Done' : '✓ Complete'}
                    </button>
                    <button
                      onClick={() => handleEdit(habit)}
                      className="px-3 py-2 rounded-xl text-xs font-semibold"
                      style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}
                    >
                      ✏️ Edit
                    </button>
                    <button
                      onClick={() => handleDelete(habit.id)}
                      className="px-3 py-2 rounded-xl text-xs font-semibold"
                      style={{ background: '#FFF0EE', color: '#E53E3E' }}
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete confirmation modal */}
      {deletingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-6"
          style={{ background: 'rgba(0,0,0,0.5)' }}>
          <div className="rounded-3xl p-6 w-full max-w-xs animate-slideUp"
            style={{ background: 'var(--card)' }}>
            <div className="text-3xl text-center mb-3">⚠️</div>
            <h3 className="font-display font-bold text-lg text-center mb-2" style={{ color: 'var(--foreground)' }}>
              Delete Habit?
            </h3>
            <p className="text-sm text-center mb-5" style={{ color: 'var(--muted-foreground)' }}>
              This will permanently delete the habit and all completion records.
            </p>
            <div className="flex gap-3">
              <button onClick={() => setDeletingId(null)}
                className="flex-1 py-3 rounded-xl text-sm font-semibold"
                style={{ background: 'var(--muted)', color: 'var(--foreground)' }}>
                Cancel
              </button>
              <button onClick={() => confirmDelete(deletingId)}
                className="flex-1 py-3 rounded-xl text-sm font-semibold"
                style={{ background: '#E53E3E', color: '#fff' }}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {showCreate && <CreateHabitModal onClose={() => setShowCreate(false)} />}
      {editingHabit && (
        <CreateHabitModal
          onClose={() => setLocalEditingHabit(null)}
          editingHabit={editingHabit}
        />
      )}
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '../store';
import AppLogo from '../components/AppLogo';

export default function LoginScreen() {
  const { login, navigate, showToast } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      showToast('Please fill in all required fields.', 'error');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const err = login(email.trim().toLowerCase(), password);
      setLoading(false);
      if (err) {
        showToast(err, 'error');
      } else {
        showToast('Login successful! Welcome back.', 'success');
        navigate('home');
      }
    }, 600);
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--background)' }}>
      {/* Header gradient */}
      <div className="flex-none py-10 flex flex-col items-center"
        style={{ background: 'linear-gradient(160deg, #E8F5F2 0%, var(--background) 100%)' }}>
        <button onClick={() => navigate('landing')} aria-label="Back to home">
          <AppLogo size="lg" showText />
        </button>
      </div>

      <div className="flex-1 px-6 pt-2 pb-8 animate-fadeIn max-w-sm w-full mx-auto">
        <h2 className="font-display font-bold text-2xl mb-1" style={{ color: 'var(--foreground)' }}>
          Welcome back
        </h2>
        <p className="text-sm mb-6" style={{ color: 'var(--muted-foreground)' }}>
          Sign in to continue your streak
        </p>

        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Email
            </label>
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none"
              style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Password
            </label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                autoComplete="current-password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none pr-12"
                style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs px-1 py-1"
                style={{ color: 'var(--muted-foreground)' }}
              >
                {showPw ? '🙈' : '👁️'}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 rounded-2xl font-semibold text-base mt-2 transition-all active:scale-95"
            style={{
              background: loading ? 'var(--muted)' : 'var(--primary)',
              color: loading ? 'var(--muted-foreground)' : 'var(--primary-foreground)',
            }}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            Don't have an account?{' '}
            <button
              onClick={() => navigate('signup')}
              className="font-semibold"
              style={{ color: 'var(--primary)' }}
            >
              Sign up
            </button>
          </p>
        </div>

        <div className="mt-8 text-center text-xs" style={{ color: 'var(--muted-foreground)' }}>
          ❤️ Take care of yourself, one habit at a time.
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useApp } from '../store';
import AppLogo from '../components/AppLogo';

export default function SplashScreen() {
  const { navigate } = useApp();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setVisible(true), 100);
    setTimeout(() => navigate('landing'), 1800);
  }, [navigate]);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center gap-8 relative overflow-hidden"
      style={{ background: 'linear-gradient(160deg, var(--background) 0%, #E8F5F2 50%, var(--background) 100%)' }}
    >
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-64 h-64 rounded-full opacity-10"
        style={{ background: 'var(--primary)', transform: 'translate(30%, -30%)' }} />
      <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full opacity-10"
        style={{ background: 'var(--secondary)', transform: 'translate(-30%, 30%)' }} />

      <div
        className="flex flex-col items-center gap-6 transition-all duration-700"
        style={{ opacity: visible ? 1 : 0, transform: visible ? 'translateY(0)' : 'translateY(24px)' }}
      >
        <AppLogo size="xl" />

        <div className="text-center px-8">
          <h1 className="font-display font-bold text-3xl mb-2" style={{ color: 'var(--foreground)' }}>
            Habit Tracker
          </h1>
          <p className="text-base" style={{ color: 'var(--muted-foreground)' }}>
            Build Better Habits. Live Better. ❤️
          </p>
        </div>
      </div>

      {/* Loading dots */}
      <div
        className="flex gap-1.5 transition-all duration-700 delay-500"
        style={{ opacity: visible ? 1 : 0 }}
      >
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className="w-2 h-2 rounded-full"
            style={{
              background: 'var(--primary)',
              opacity: 0.6,
              animation: `pulse-scale 1.2s ease-in-out ${i * 0.2}s infinite`,
            }}
          />
        ))}
      </div>

      <div
        className="absolute bottom-12 text-xs transition-all duration-700 delay-700"
        style={{ color: 'var(--muted-foreground)', opacity: visible ? 1 : 0 }}
      >
        ❤️ Take care of yourself, one habit at a time.
      </div>
    </div>
  );
}

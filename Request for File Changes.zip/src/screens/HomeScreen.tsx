import { useState } from 'react';
import { useApp, getTodayStr, calculateCurrentStreak, calculateOverallStreak } from '../store';
import { CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import CreateHabitModal from '../components/CreateHabitModal';
import { LogoMark } from '../components/AppLogo';

function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function HomeScreen() {
  const { currentUser, habits, completions, navigate, showToast, completeHabit } = useApp();
  const [showCreate, setShowCreate] = useState(false);
  const [completing, setCompleting] = useState<string | null>(null);

  if (!currentUser) return null;

  const today = getTodayStr();
  const userHabits = habits.filter(h => h.userId === currentUser.id && h.active);
  const todayHabits = userHabits.filter(h => h.frequency === 'Daily' || h.frequency === 'Weekly' || h.frequency === 'Custom');
  const completedToday = todayHabits.filter(h =>
    completions.some(c => c.habitId === h.id && c.date === today && c.completed)
  );
  const remainingToday = todayHabits.length - completedToday.length;
  const pct = todayHabits.length > 0 ? Math.round((completedToday.length / todayHabits.length) * 100) : 0;
  const overallStreak = calculateOverallStreak(currentUser.id, userHabits, completions);

  async function handleComplete(habitId: string) {
    setCompleting(habitId);
    setTimeout(() => {
      const success = completeHabit(habitId, today);
      setCompleting(null);
      if (success) {
        const allDone = remainingToday === 1;
        if (allDone) {
          showToast('All habits completed today! 🎉', 'success');
        } else {
          const streak = calculateCurrentStreak(habitId, completions);
          if (streak > 0 && streak % 5 === 0) {
            showToast(`${streak} Day Streak! Keep going! 🔥`, 'success');
          } else {
            showToast('Great job! Habit completed successfully. ❤️', 'success');
          }
        }
      } else {
        showToast('Already completed today!', 'info');
      }
    }, 300);
  }

  const circumference = 2 * Math.PI * 36;
  const dashOffset = circumference - (pct / 100) * circumference;

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-6"
        style={{ background: 'linear-gradient(135deg, var(--primary) 0%, #1F7D73 100%)' }}>
        <div className="max-w-sm mx-auto">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => navigate('landing')} aria-label="Go to public home">
              <LogoMark size={32} />
            </button>
            <button
              onClick={() => navigate('settings')}
              className="w-9 h-9 rounded-full flex items-center justify-center text-lg"
              style={{ background: 'rgba(255,255,255,0.15)' }}>
              ⚙️
            </button>
          </div>
          <p className="text-sm opacity-80 text-white mb-0.5">{formatDate(new Date())}</p>
          <h1 className="font-display font-bold text-2xl text-white">
            {getGreeting()}, {currentUser.name.split(' ')[0]}! 👋
          </h1>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Stats row */}
        <div className="grid grid-cols-2 gap-3 -mt-4 mb-5">
          {/* Progress ring card */}
          <div className="rounded-2xl p-4 shadow-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex items-center gap-3">
              <div className="relative flex-none">
                <svg width="88" height="88" viewBox="0 0 88 88">
                  <circle cx="44" cy="44" r="36" fill="none" stroke="var(--muted)" strokeWidth="8" />
                  <circle
                    cx="44" cy="44" r="36" fill="none"
                    stroke="var(--primary)" strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    strokeDashoffset={dashOffset}
                    className="ring-progress"
                  />
                  <text x="44" y="48" textAnchor="middle" style={{ fontSize: 18, fontWeight: 700, fill: 'var(--foreground)', fontFamily: 'Outfit, sans-serif' }}>
                    {pct}%
                  </text>
                </svg>
              </div>
              <div>
                <p className="text-xs font-medium" style={{ color: 'var(--muted-foreground)' }}>Today's</p>
                <p className="text-sm font-bold" style={{ color: 'var(--foreground)' }}>Progress 🎯</p>
                <p className="text-xs mt-1" style={{ color: 'var(--muted-foreground)' }}>
                  {completedToday.length}/{todayHabits.length} done
                </p>
              </div>
            </div>
          </div>

          {/* Streak card */}
          <div className="rounded-2xl p-4 shadow-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="text-3xl mb-1">🔥</div>
            <p className="font-display font-bold text-2xl" style={{ color: 'var(--accent)' }}>
              {overallStreak}
            </p>
            <p className="text-xs font-medium" style={{ color: 'var(--muted-foreground)' }}>Day Streak</p>
            {overallStreak >= 7 && (
              <p className="text-xs mt-1" style={{ color: 'var(--accent)' }}>🏆 Amazing!</p>
            )}
          </div>
        </div>

        {/* Mini stats */}
        <div className="grid grid-cols-3 gap-2 mb-5">
          {[
            { label: 'Active', value: userHabits.length, icon: '📋' },
            { label: 'Completed', value: completedToday.length, icon: '✅' },
            { label: 'Remaining', value: remainingToday, icon: '⏳' },
          ].map(stat => (
            <div key={stat.label} className="rounded-xl p-3 text-center" style={{ background: 'var(--muted)' }}>
              <div className="text-lg">{stat.icon}</div>
              <p className="font-bold text-lg" style={{ color: 'var(--foreground)' }}>{stat.value}</p>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Today's Habits */}
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-bold text-lg" style={{ color: 'var(--foreground)' }}>
            Today's Habits
          </h2>
          <button
            onClick={() => setShowCreate(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold transition-all"
            style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
          >
            + Add
          </button>
        </div>

        {todayHabits.length === 0 ? (
          <div className="text-center py-12 rounded-2xl" style={{ background: 'var(--muted)' }}>
            <div className="text-4xl mb-3">🌱</div>
            <p className="font-medium mb-1" style={{ color: 'var(--foreground)' }}>No habits yet</p>
            <p className="text-sm mb-4" style={{ color: 'var(--muted-foreground)' }}>
              Create your first habit! 🎯
            </p>
            <button
              onClick={() => setShowCreate(true)}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold"
              style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
            >
              Create Habit
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {todayHabits.map(habit => {
              const done = completions.some(c => c.habitId === habit.id && c.date === today && c.completed);
              const streak = calculateCurrentStreak(habit.id, completions);
              const color = CATEGORY_COLORS[habit.category];
              const isCompleting = completing === habit.id;

              return (
                <div
                  key={habit.id}
                  className="rounded-2xl p-4 transition-all"
                  style={{
                    background: 'var(--card)',
                    border: `1.5px solid ${done ? color + '40' : 'var(--border)'}`,
                    opacity: done ? 0.85 : 1,
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-none text-lg"
                      style={{ background: color + '20' }}>
                      {CATEGORY_ICONS[habit.category]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm leading-tight" style={{
                        color: 'var(--foreground)',
                        textDecoration: done ? 'line-through' : 'none',
                      }}>
                        {habit.name}
                      </p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                        {habit.target}
                      </p>
                      {streak > 0 && (
                        <p className="text-xs mt-1" style={{ color: 'var(--accent)' }}>
                          🔥 {streak} day streak
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => handleComplete(habit.id)}
                      disabled={done || isCompleting}
                      className="w-9 h-9 rounded-full flex items-center justify-center flex-none text-sm transition-all active:scale-90"
                      style={{
                        background: done ? color : isCompleting ? 'var(--muted)' : 'transparent',
                        border: done ? 'none' : `2px solid ${color}`,
                        color: done ? '#fff' : color,
                      }}
                    >
                      {done ? '✓' : isCompleting ? '...' : '○'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Suggestions CTA */}
        <button
          onClick={() => navigate('suggestions')}
          className="mt-5 w-full p-4 rounded-2xl text-left flex items-center gap-3 transition-all"
          style={{ background: 'linear-gradient(135deg, #E8F5F2, #F0F8E8)', border: '1px solid var(--border)' }}
        >
          <span className="text-2xl">💡</span>
          <div>
            <p className="text-sm font-semibold" style={{ color: 'var(--secondary)' }}>
              Discover Healthy Habits
            </p>
            <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
              Browse curated habit suggestions ❤️
            </p>
          </div>
          <span className="ml-auto" style={{ color: 'var(--muted-foreground)' }}>›</span>
        </button>

        {/* Wellness tip */}
        <div className="mt-3 mb-2 p-4 rounded-2xl"
          style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
          <p className="text-xs font-medium mb-0.5" style={{ color: 'var(--primary)' }}>Daily Reminder</p>
          <p className="text-sm" style={{ color: 'var(--foreground)' }}>
            ❤️ Every small step counts. You're doing great!
          </p>
        </div>
      </div>

      {showCreate && <CreateHabitModal onClose={() => setShowCreate(false)} />}
    </div>
  );
}

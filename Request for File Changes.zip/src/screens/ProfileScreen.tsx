import { useRef, useState } from 'react';
import { useApp, getTodayStr, calculateLongestStreak, calculateOverallStreak } from '../store';
import type { UserType } from '../types';

export default function ProfileScreen() {
  const { currentUser, habits, completions, updateUser, navigate, showToast, settings } = useApp();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name ?? '');
  const [userType, setUserType] = useState(currentUser?.userType ?? '');
  const [photoSheet, setPhotoSheet] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoError, setPhotoError] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInput = useRef<HTMLInputElement>(null);

  if (!currentUser) return null;

  const userHabits = habits.filter(h => h.userId === currentUser.id && h.active);
  const today = getTodayStr();
  const completedToday = userHabits.filter(h =>
    completions.some(c => c.habitId === h.id && c.date === today && c.completed)
  ).length;

  const totalCompletions = completions.filter(c => c.userId === currentUser.id && c.completed).length;
  const overallStreak = calculateOverallStreak(currentUser.id, userHabits, completions);
  const longestStreak = userHabits.reduce((max, h) => {
    const l = calculateLongestStreak(h.id, completions);
    return Math.max(max, l);
  }, 0);

  function handleSave() {
    if (!name.trim()) { showToast('Name cannot be empty.', 'error'); return; }
    const uid = currentUser?.id;
    if (!uid) return;
    updateUser(uid, { name: name.trim(), userType: userType as UserType });
    showToast('Profile updated! ✨', 'success');
    setEditing(false);
  }

  function getInitials(n: string) {
    return n.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
  }

  function handlePhoto(file?: File) {
    if (!file) return;
    if (!['image/jpeg', 'image/png'].includes(file.type) || file.size > 5 * 1024 * 1024) {
      setPhotoError('Please choose a JPG or PNG image up to 5 MB.');
      return;
    }
    setPhotoError('');
    const reader = new FileReader();
    reader.onload = () => { setPhotoPreview(String(reader.result)); setPhotoSheet(false); };
    reader.readAsDataURL(file);
  }

  function savePhoto() {
    if (!photoPreview) return;
    setUploadProgress(25);
    const timer = window.setInterval(() => setUploadProgress(value => {
      if (value >= 100) {
        window.clearInterval(timer);
        updateUser(currentUser.id, { profileImage: photoPreview });
        setPhotoPreview(null);
        showToast('Profile photo updated.', 'success');
        return 0;
      }
      return Math.min(100, value + 25);
    }), 180);
  }

  const initials = getInitials(currentUser.name);

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-16 relative"
        style={{ background: 'linear-gradient(135deg, #9B59B6 0%, #7D3C98 100%)' }}>
        <div className="max-w-sm mx-auto">
          <div className="flex items-center justify-between mb-2">
            <p className="text-white opacity-70 text-xs">My Account</p>
            <button
              onClick={() => navigate('settings')}
              className="text-xs px-3 py-1.5 rounded-full font-medium"
              style={{ background: 'rgba(255,255,255,0.15)', color: '#fff' }}
            >
              ⚙️ Settings
            </button>
          </div>
          <h1 className="font-display font-bold text-2xl text-white">Profile</h1>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Avatar card */}
        <div className="rounded-3xl p-5 -mt-10 mb-5 shadow-md"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="flex items-center gap-4">
            <button onClick={() => setPhotoSheet(true)} className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center font-display font-bold text-2xl flex-none"
              style={{ background: 'linear-gradient(135deg, var(--primary), var(--secondary))', color: '#fff' }}>
              {currentUser.profileImage ? <img src={currentUser.profileImage} alt="" className="w-full h-full object-cover" /> : initials}
            </button>
            <div className="flex-1 min-w-0">
              <p className="font-display font-bold text-lg leading-tight" style={{ color: 'var(--foreground)' }}>
                {currentUser.name}
              </p>
              <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{currentUser.email}</p>
              <span className="inline-block mt-1 text-xs px-2.5 py-0.5 rounded-full font-medium"
                style={{ background: 'var(--primary)' + '20', color: 'var(--primary)' }}>
                {currentUser.userType}
              </span>
              <span className="inline-block mt-1 ml-1 text-xs px-2.5 py-0.5 rounded-full font-medium capitalize"
                style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>
                {settings.privacy}
              </span>
            </div>
            {!editing && (
              <button
                onClick={() => { setEditing(true); setName(currentUser.name); setUserType(currentUser.userType); }}
                className="w-8 h-8 rounded-xl flex items-center justify-center text-sm"
                style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}
              >
                ✏️
              </button>
            )}
          </div>

          <div className="mt-3 text-xs" style={{ color: 'var(--muted-foreground)' }}>
            Member since {new Date(currentUser.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </div>
        </div>

        {/* Edit form */}
        {editing && (
          <div className="rounded-2xl p-4 mb-5 animate-fadeIn"
            style={{ background: 'var(--card)', border: '1.5px solid var(--primary)' }}>
            <h3 className="font-semibold text-sm mb-3" style={{ color: 'var(--foreground)' }}>Edit Profile</h3>
            <div className="flex flex-col gap-3">
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl text-sm outline-none"
                  style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
                />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>User Type</label>
                <select
                  value={userType}
                  onChange={e => setUserType(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl text-sm outline-none"
                  style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
                >
                  {['Student', 'Fitness Enthusiast', 'Working Professional', 'Senior/Elder', 'General User', 'Other'].map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2 mt-1">
                <button onClick={() => setEditing(false)}
                  className="flex-1 py-2.5 rounded-xl text-sm font-medium"
                  style={{ background: 'var(--muted)', color: 'var(--foreground)' }}>
                  Cancel
                </button>
                <button onClick={handleSave}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                  style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        <h2 className="font-display font-bold text-base mb-3" style={{ color: 'var(--foreground)' }}>
          Statistics
        </h2>
        <div className="grid grid-cols-2 gap-3 mb-5">
          {[
            { label: 'Active Habits', value: userHabits.length, icon: '📋', color: 'var(--primary)' },
            { label: 'Completed Today', value: completedToday, icon: '✅', color: 'var(--secondary)' },
            { label: 'Total Completions', value: totalCompletions, icon: '🎯', color: '#6B7FF0' },
            { label: 'Current Streak', value: `${overallStreak}🔥`, icon: '', color: 'var(--accent)' },
          ].map(s => (
            <div key={s.label} className="rounded-2xl p-4"
              style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <p className="font-bold text-2xl mb-0.5" style={{ color: s.color }}>{s.value}</p>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Streak summary */}
        <div className="rounded-2xl p-4 mb-5"
          style={{ background: 'linear-gradient(135deg, var(--primary)15, var(--secondary)15)', border: '1px solid var(--border)' }}>
          <div className="flex justify-around">
            <div className="text-center">
              <p className="text-2xl font-bold" style={{ color: 'var(--accent)' }}>🔥 {overallStreak}</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>Current Streak</p>
            </div>
            <div style={{ width: 1, background: 'var(--border)' }} />
            <div className="text-center">
              <p className="text-2xl font-bold" style={{ color: 'var(--secondary)' }}>🏆 {longestStreak}</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>Longest Streak</p>
            </div>
          </div>
        </div>

        {/* Admin shortcut */}
        {currentUser.isAdmin && (
          <button
            onClick={() => navigate('admin')}
            className="w-full py-3.5 rounded-2xl text-sm font-semibold mb-3 transition-all"
            style={{ background: 'var(--accent)', color: 'var(--accent-foreground)' }}
          >
            👑 Admin Panel — Manage Users
          </button>
        )}
      </div>

      <input ref={fileInput} type="file" accept="image/jpeg,image/png" className="hidden" onChange={e => handlePhoto(e.target.files?.[0])} />

      {photoSheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={() => setPhotoSheet(false)} style={{ background: 'rgba(0,0,0,.5)' }}>
          <div className="w-full max-w-md rounded-t-3xl p-5" onClick={e => e.stopPropagation()} style={{ background: 'var(--card)' }}>
            <div className="w-10 h-1 rounded-full mx-auto mb-5" style={{ background: 'var(--border)' }} />
            <h2 className="font-display font-bold text-lg mb-3">Profile photo</h2>
            <button onClick={() => fileInput.current?.click()} className="w-full text-left py-3.5" style={{ borderBottom: '1px solid var(--border)' }}>Choose from gallery</button>
            <button onClick={() => fileInput.current?.click()} className="w-full text-left py-3.5" style={{ borderBottom: '1px solid var(--border)' }}>Take photo</button>
            <button onClick={() => { updateUser(currentUser.id, { profileImage: undefined }); setPhotoSheet(false); showToast('Profile photo removed.', 'info'); }} className="w-full text-left py-3.5" style={{ color: '#C43D3D' }}>Remove photo</button>
            {photoError && <p className="text-xs mt-2" role="alert" style={{ color: '#C43D3D' }}>{photoError}</p>}
          </div>
        </div>
      )}

      {photoPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5" style={{ background: 'rgba(0,0,0,.72)' }}>
          <div className="w-full max-w-sm rounded-3xl p-6 text-center" style={{ background: 'var(--card)' }}>
            <h2 className="font-display font-bold text-xl mb-2">Crop profile photo</h2>
            <p className="text-sm mb-5" style={{ color: 'var(--muted-foreground)' }}>Position your photo inside the circle.</p>
            <div className="w-56 h-56 rounded-full overflow-hidden mx-auto mb-5" style={{ border: '4px solid var(--primary)' }}><img src={photoPreview} alt="Profile preview" className="w-full h-full object-cover" /></div>
            {uploadProgress > 0 && <div className="h-2 rounded-full overflow-hidden mb-4" style={{ background: 'var(--muted)' }}><div className="h-full transition-all" style={{ width: `${uploadProgress}%`, background: 'var(--primary)' }} /></div>}
            <div className="flex gap-2"><button onClick={() => { setPhotoPreview(null); setUploadProgress(0); }} className="flex-1 py-3 rounded-xl" style={{ background: 'var(--muted)' }}>Cancel</button><button onClick={savePhoto} disabled={uploadProgress > 0} className="flex-1 py-3 rounded-xl font-semibold disabled:opacity-50" style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>Upload photo</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

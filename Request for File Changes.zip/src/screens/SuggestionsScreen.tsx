import { useState } from 'react';
import { useApp } from '../store';
import { HABIT_CATEGORIES, CATEGORY_ICONS, CATEGORY_COLORS } from '../types';
import type { HabitCategory } from '../types';

export default function SuggestionsScreen() {
  const { currentUser, suggestions, addSuggestion, showToast } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [filterCat, setFilterCat] = useState<HabitCategory | 'All'>('All');

  // Submit form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<HabitCategory>('Fitness');
  const [target, setTarget] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!currentUser) return null;

  const filtered = suggestions.filter(s =>
    s.status === 'approved' && (filterCat === 'All' || s.category === filterCat)
  );

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) { showToast('Please enter a title.', 'error'); return; }
    if (!description.trim()) { showToast('Please add a description.', 'error'); return; }

    setSubmitting(true);
    setTimeout(() => {
      addSuggestion({ title: title.trim(), description: description.trim(), category, target, recommendation: '' });
      showToast('Suggestion submitted! 🌟', 'success');
      setTitle(''); setDescription(''); setTarget(''); setCategory('Fitness');
      setShowForm(false);
      setSubmitting(false);
    }, 500);
  }

  const categories: (HabitCategory | 'All')[] = ['All', ...HABIT_CATEGORIES];

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, #27AE60 0%, #1E8449 100%)' }}>
        <div className="max-w-sm mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-white opacity-70 mb-0.5">Community</p>
              <h1 className="font-display font-bold text-2xl text-white">Habit Ideas ❤️</h1>
            </div>
            <button
              onClick={() => setShowForm(!showForm)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-xl font-bold"
              style={{ background: 'rgba(255,255,255,0.2)', color: '#fff' }}
            >
              {showForm ? '✕' : '+'}
            </button>
          </div>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Submit form */}
        {showForm && (
          <div className="mt-4 rounded-2xl p-5 animate-slideUp"
            style={{ background: 'var(--card)', border: '1.5px solid var(--primary)' }}>
            <h3 className="font-display font-bold text-base mb-4" style={{ color: 'var(--foreground)' }}>
              Suggest a Habit 🌱
            </h3>
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <input
                type="text" value={title} onChange={e => setTitle(e.target.value)}
                placeholder="Habit name *"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              <textarea
                value={description} onChange={e => setDescription(e.target.value)}
                placeholder="Describe this habit and its benefits *"
                rows={2}
                className="w-full px-4 py-3 rounded-xl text-sm outline-none resize-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              <input
                type="text" value={target} onChange={e => setTarget(e.target.value)}
                placeholder="Target (e.g. 30 minutes)"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              <div className="grid grid-cols-2 gap-2">
                {HABIT_CATEGORIES.map(cat => (
                  <button key={cat} type="button" onClick={() => setCategory(cat)}
                    className="px-3 py-2 rounded-xl text-xs font-medium text-left transition-all"
                    style={{
                      background: category === cat ? 'var(--primary)' : 'var(--muted)',
                      color: category === cat ? 'var(--primary-foreground)' : 'var(--foreground)',
                      border: category === cat ? '1.5px solid var(--primary)' : '1.5px solid var(--border)',
                    }}>
                    {CATEGORY_ICONS[cat]} {cat}
                  </button>
                ))}
              </div>
              <button type="submit" disabled={submitting}
                className="w-full py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-95"
                style={{ background: 'var(--secondary)', color: 'var(--secondary-foreground)' }}>
                {submitting ? 'Submitting...' : 'Submit Suggestion 🌟'}
              </button>
            </form>
          </div>
        )}

        {/* Category filter */}
        <div className="flex gap-2 mt-4 mb-4 overflow-x-auto pb-1 no-scrollbar">
          {categories.map(cat => {
            const active = filterCat === cat;
            const color = cat === 'All' ? 'var(--primary)' : CATEGORY_COLORS[cat as HabitCategory];
            return (
              <button
                key={cat}
                onClick={() => setFilterCat(cat)}
                className="flex-none px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all"
                style={{
                  background: active ? color : 'var(--muted)',
                  color: active ? '#fff' : 'var(--muted-foreground)',
                }}
              >
                {cat === 'All' ? '✨ All' : `${CATEGORY_ICONS[cat as HabitCategory]} ${cat}`}
              </button>
            );
          })}
        </div>

        {/* Suggestions list */}
        {filtered.length === 0 ? (
          <div className="text-center py-12 rounded-2xl" style={{ background: 'var(--muted)' }}>
            <div className="text-4xl mb-3">💡</div>
            <p className="font-medium" style={{ color: 'var(--foreground)' }}>
              No suggestions available yet.
            </p>
            <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
              Be the first to share a healthy habit!
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {filtered.map(s => {
              const color = CATEGORY_COLORS[s.category];
              return (
                <div
                  key={s.id}
                  className="rounded-2xl p-4"
                  style={{ background: 'var(--card)', border: `1px solid var(--border)` }}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-none"
                      style={{ background: color + '20' }}>
                      {CATEGORY_ICONS[s.category]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm" style={{ color: 'var(--foreground)' }}>
                        {s.title}
                      </p>
                      <span className="text-xs px-1.5 py-0.5 rounded-full"
                        style={{ background: color + '20', color }}>
                        {s.category}
                      </span>
                    </div>
                    {!s.isDefault && (
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: 'var(--secondary)' + '20', color: 'var(--secondary)' }}>
                        User
                      </span>
                    )}
                  </div>

                  <p className="text-sm mt-2 leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                    {s.description}
                  </p>

                  {(s.target || s.recommendation) && (
                    <div className="mt-2 flex flex-col gap-1">
                      {s.target && (
                        <p className="text-xs" style={{ color: 'var(--foreground)' }}>
                          🎯 <span style={{ color: 'var(--muted-foreground)' }}>Target:</span> {s.target}
                        </p>
                      )}
                      {s.recommendation && (
                        <p className="text-xs" style={{ color: 'var(--foreground)' }}>
                          💡 <span style={{ color: 'var(--muted-foreground)' }}>Tip:</span> {s.recommendation}
                        </p>
                      )}
                    </div>
                  )}

                  <div className="mt-2 text-xs" style={{ color: 'var(--muted-foreground)' }}>
                    Shared by {s.userName}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

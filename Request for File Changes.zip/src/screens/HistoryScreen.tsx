import { useMemo, useState } from 'react';
import { useApp } from '../store';

export default function HistoryScreen() {
  const { currentUser, habits, completions } = useApp();
  const [tab, setTab] = useState<'habits' | 'devices'>('habits');
  const [activity, setActivity] = useState('all');
  const [date, setDate] = useState('');

  const rows = useMemo(() => {
    if (!currentUser) return [];
    return habits.filter(h => h.userId === currentUser.id).flatMap(h => {
      const completed = completions.filter(c => c.habitId === h.id && c.userId === currentUser.id);
      const items = [{ id: `${h.id}-created`, habit: h.name, status: 'Created', time: h.createdAt }];
      completed.forEach(c => items.push({ id: c.id, habit: h.name, status: c.completed ? 'Completed' : 'Missed', time: c.completedAt }));
      return items;
    }).filter(row => activity === 'all' || row.status.toLowerCase() === activity)
      .filter(row => !date || row.time.slice(0, 10) === date)
      .sort((a, b) => b.time.localeCompare(a.time));
  }, [activity, completions, currentUser, date, habits]);

  const completed = rows.filter(r => r.status === 'Completed').length;

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      <div className="px-5 pt-12 pb-6" style={{ background: 'linear-gradient(135deg, #425F5B, #274642)' }}>
        <div className="max-w-sm mx-auto"><p className="text-xs text-white opacity-70">Private activity</p><h1 className="font-display font-bold text-2xl text-white">History</h1></div>
      </div>
      <div className="px-5 max-w-sm mx-auto py-5">
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[['Activities', rows.length], ['Completed', completed], ['Devices', 1]].map(([label, value]) => (
            <div key={label} className="rounded-2xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}><p className="text-2xl font-bold">{value}</p><p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{label}</p></div>
          ))}
        </div>
        <div className="flex gap-2 mb-4">
          <button onClick={() => setTab('habits')} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: tab === 'habits' ? 'var(--primary)' : 'var(--muted)', color: tab === 'habits' ? 'var(--primary-foreground)' : 'var(--foreground)' }}>Habit History</button>
          <button onClick={() => setTab('devices')} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: tab === 'devices' ? 'var(--primary)' : 'var(--muted)', color: tab === 'devices' ? 'var(--primary-foreground)' : 'var(--foreground)' }}>Device History</button>
        </div>
        {tab === 'habits' ? (
          <>
            <div className="flex gap-2 mb-4">
              <select value={activity} onChange={e => setActivity(e.target.value)} className="flex-1 px-3 py-2 rounded-xl text-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}><option value="all">All activities</option><option value="created">Created</option><option value="completed">Completed</option><option value="missed">Missed</option></select>
              <input type="date" value={date} onChange={e => setDate(e.target.value)} className="flex-1 px-3 py-2 rounded-xl text-sm" style={{ background: 'var(--card)', border: '1px solid var(--border)' }} />
            </div>
            {rows.length ? <div className="rounded-2xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>{rows.map(row => <div key={row.id} className="flex items-center gap-3 p-4" style={{ borderBottom: '1px solid var(--border)' }}><span className="w-2.5 h-2.5 rounded-full" style={{ background: row.status === 'Completed' ? 'var(--secondary)' : row.status === 'Missed' ? 'var(--accent)' : 'var(--primary)' }} /><div className="flex-1"><p className="text-sm font-semibold">{row.habit}</p><p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{row.status}</p></div><time className="text-xs text-right" style={{ color: 'var(--muted-foreground)' }}>{new Date(row.time).toLocaleDateString()}<br />{new Date(row.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</time></div>)}</div> : <div className="text-center py-16 rounded-2xl" style={{ background: 'var(--muted)' }}><p className="font-semibold">No activity found</p><p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>Try changing your filters.</p></div>}
          </>
        ) : (
          <div className="rounded-2xl p-5 flex items-center gap-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}><span className="w-12 h-12 rounded-xl grid place-items-center font-bold" style={{ background: 'var(--muted)' }}>PC</span><div className="flex-1"><p className="font-semibold">Current browser</p><p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{navigator.platform || 'Web device'} · Signed in this session</p></div><span className="text-xs font-semibold" style={{ color: 'var(--secondary)' }}>Online</span></div>
        )}
      </div>
    </div>
  );
}

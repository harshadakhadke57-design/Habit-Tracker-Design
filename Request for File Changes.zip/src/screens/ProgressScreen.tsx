import { useState } from 'react';
import { useApp, getDateStr, getTodayStr, calculateCurrentStreak, calculateLongestStreak, calculateOverallStreak } from '../store';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type Period = 'daily' | 'weekly' | 'monthly';

function getWeekDates(): string[] {
  return Array.from({ length: 7 }, (_, i) => getDateStr(6 - i));
}

function getMonthDates(): string[] {
  const today = new Date();
  const days = today.getDate();
  return Array.from({ length: days }, (_, i) => getDateStr(days - 1 - i));
}

export default function ProgressScreen() {
  const { currentUser, habits, completions } = useApp();
  const [period, setPeriod] = useState<Period>('weekly');

  if (!currentUser) return null;

  const today = getTodayStr();
  const userHabits = habits.filter(h => h.userId === currentUser.id && h.active);

  function getDayStats(dateStr: string) {
    const dayDone = completions.filter(c => c.userId === currentUser!.id && c.date === dateStr && c.completed).length;
    const habitsOnDay = userHabits.filter(h => h.startDate <= dateStr).length;
    const missed = habitsOnDay > 0 && dateStr <= today ? Math.max(0, habitsOnDay - dayDone) : 0;
    const pct = habitsOnDay > 0 ? Math.round((dayDone / habitsOnDay) * 100) : 0;
    return { completed: dayDone, missed, pct, total: habitsOnDay };
  }

  const todayStats = getDayStats(today);
  const overallStreak = calculateOverallStreak(currentUser.id, userHabits, completions);
  const allHabitsLongest = userHabits.reduce((max, h) => {
    const l = calculateLongestStreak(h.id, completions);
    return Math.max(max, l);
  }, 0);

  // Weekly chart data
  const weekDates = getWeekDates();
  const weekData = weekDates.map(d => {
    const s = getDayStats(d);
    const dayName = new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short' });
    return { day: dayName, completed: s.completed, missed: s.missed, pct: s.pct };
  });

  const weeklyCompleted = weekData.reduce((sum, d) => sum + d.completed, 0);
  const weeklyMissed = weekData.reduce((sum, d) => sum + d.missed, 0);
  const weeklyPct = weekData.length > 0
    ? Math.round(weekData.reduce((sum, d) => sum + d.pct, 0) / weekData.filter(d => d.pct > 0 || getDayStats(weekDates[weekData.indexOf(d)]).total > 0).length || 0)
    : 0;

  // Monthly chart data (last 30 days summarized by week)
  const monthDates = getMonthDates();
  const monthData: { week: string; completed: number; missed: number }[] = [];
  for (let w = 0; w < 5; w++) {
    const start = w * 7;
    const end = Math.min(start + 7, monthDates.length);
    if (start >= monthDates.length) break;
    const weekSlice = monthDates.slice(start, end);
    const wCompleted = weekSlice.reduce((s, d) => s + getDayStats(d).completed, 0);
    const wMissed = weekSlice.reduce((s, d) => s + getDayStats(d).missed, 0);
    monthData.push({ week: `W${w + 1}`, completed: wCompleted, missed: wMissed });
  }

  const monthlyCompleted = monthData.reduce((s, d) => s + d.completed, 0);
  const monthlyMissed = monthData.reduce((s, d) => s + d.missed, 0);
  const monthlyTotal = monthlyCompleted + monthlyMissed;
  const monthlyPct = monthlyTotal > 0 ? Math.round((monthlyCompleted / monthlyTotal) * 100) : 0;

  const chartConfig = { completed: '#2D9D92', missed: '#E8602C' };

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, #D4821A 0%, #B86A10 100%)' }}>
        <div className="max-w-sm mx-auto">
          <p className="text-xs text-white opacity-70 mb-0.5">Analytics</p>
          <h1 className="font-display font-bold text-2xl text-white">Progress</h1>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Period tabs */}
        <div className="flex gap-2 mt-4 mb-5">
          {(['daily', 'weekly', 'monthly'] as Period[]).map(p => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className="flex-1 py-2 rounded-xl text-xs font-semibold capitalize transition-all"
              style={{
                background: period === p ? 'var(--accent)' : 'var(--muted)',
                color: period === p ? 'var(--accent-foreground)' : 'var(--muted-foreground)',
              }}
            >
              {p}
            </button>
          ))}
        </div>

        {userHabits.length === 0 ? (
          <div className="text-center py-16 rounded-2xl" style={{ background: 'var(--muted)' }}>
            <div className="text-4xl mb-3">📊</div>
            <p className="font-medium" style={{ color: 'var(--foreground)' }}>
              Complete some habits to see your progress.
            </p>
          </div>
        ) : (
          <>
            {/* Daily */}
            {period === 'daily' && (
              <div className="flex flex-col gap-4 animate-fadeIn">
                <h2 className="font-display font-bold text-base" style={{ color: 'var(--foreground)' }}>
                  Today's Progress
                </h2>

                {/* Ring */}
                <div className="rounded-2xl p-5 flex items-center gap-4"
                  style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <svg width="100" height="100" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" fill="none" stroke="var(--muted)" strokeWidth="10" />
                    <circle cx="50" cy="50" r="40" fill="none"
                      stroke="var(--primary)" strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray={2 * Math.PI * 40}
                      strokeDashoffset={2 * Math.PI * 40 * (1 - todayStats.pct / 100)}
                      className="ring-progress"
                    />
                    <text x="50" y="54" textAnchor="middle"
                      style={{ fontSize: 20, fontWeight: 700, fill: 'var(--foreground)', fontFamily: 'Outfit' }}>
                      {todayStats.pct}%
                    </text>
                  </svg>
                  <div>
                    <p className="font-display font-bold text-xl mb-1" style={{ color: 'var(--foreground)' }}>
                      Daily Report
                    </p>
                    <div className="flex flex-col gap-1">
                      <p className="text-sm"><span style={{ color: 'var(--secondary)' }}>✅ Completed:</span> {todayStats.completed}</p>
                      <p className="text-sm"><span style={{ color: '#E8602C' }}>❌ Missed:</span> {todayStats.missed}</p>
                    </div>
                  </div>
                </div>

                {/* Streak cards */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl p-4 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="text-2xl mb-1">🔥</div>
                    <p className="font-bold text-2xl" style={{ color: 'var(--accent)' }}>{overallStreak}</p>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Current Streak</p>
                  </div>
                  <div className="rounded-xl p-4 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="text-2xl mb-1">🏆</div>
                    <p className="font-bold text-2xl" style={{ color: 'var(--secondary)' }}>{allHabitsLongest}</p>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Longest Streak</p>
                  </div>
                </div>
              </div>
            )}

            {/* Weekly */}
            {period === 'weekly' && (
              <div className="flex flex-col gap-4 animate-fadeIn">
                <h2 className="font-display font-bold text-base" style={{ color: 'var(--foreground)' }}>
                  This Week
                </h2>

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Completion', value: `${weeklyPct || 0}%`, icon: '📈' },
                    { label: 'Completed', value: weeklyCompleted, icon: '✅' },
                    { label: 'Missed', value: weeklyMissed, icon: '❌' },
                  ].map(s => (
                    <div key={s.label} className="rounded-xl p-3 text-center"
                      style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                      <div className="text-lg">{s.icon}</div>
                      <p className="font-bold text-lg" style={{ color: 'var(--foreground)' }}>{s.value}</p>
                      <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{s.label}</p>
                    </div>
                  ))}
                </div>

                {/* Bar chart */}
                <div className="rounded-2xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <p className="text-xs font-semibold mb-3" style={{ color: 'var(--muted-foreground)' }}>
                    Completions by Day
                  </p>
                  <ResponsiveContainer width="100%" height={150}>
                    <BarChart data={weekData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="day" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }}
                        labelStyle={{ color: 'var(--foreground)', fontWeight: 600 }}
                      />
                      <Bar dataKey="completed" fill={chartConfig.completed} radius={[4, 4, 0, 0]} name="Completed" />
                      <Bar dataKey="missed" fill={chartConfig.missed} radius={[4, 4, 0, 0]} name="Missed" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="rounded-xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">🔥</span>
                    <div>
                      <p className="font-bold text-lg" style={{ color: 'var(--accent)' }}>{overallStreak} Day Streak</p>
                      <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Keep it going!</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Monthly */}
            {period === 'monthly' && (
              <div className="flex flex-col gap-4 animate-fadeIn">
                <h2 className="font-display font-bold text-base" style={{ color: 'var(--foreground)' }}>
                  This Month
                </h2>

                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Monthly %', value: `${monthlyPct}%`, icon: '📊', color: 'var(--primary)' },
                    { label: 'Completed', value: monthlyCompleted, icon: '✅', color: 'var(--secondary)' },
                    { label: 'Missed', value: monthlyMissed, icon: '❌', color: '#E8602C' },
                    { label: 'Active Habits', value: userHabits.length, icon: '📋', color: 'var(--accent)' },
                  ].map(s => (
                    <div key={s.label} className="rounded-xl p-4"
                      style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                      <div className="text-xl mb-1">{s.icon}</div>
                      <p className="font-bold text-xl" style={{ color: s.color }}>{s.value}</p>
                      <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{s.label}</p>
                    </div>
                  ))}
                </div>

                {/* Monthly chart */}
                <div className="rounded-2xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <p className="text-xs font-semibold mb-3" style={{ color: 'var(--muted-foreground)' }}>
                    Completions by Week
                  </p>
                  <ResponsiveContainer width="100%" height={150}>
                    <BarChart data={monthData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="week" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                      <Tooltip
                        contentStyle={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }}
                        labelStyle={{ color: 'var(--foreground)', fontWeight: 600 }}
                      />
                      <Bar dataKey="completed" fill={chartConfig.completed} radius={[4, 4, 0, 0]} name="Completed" />
                      <Bar dataKey="missed" fill={chartConfig.missed} radius={[4, 4, 0, 0]} name="Missed" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl p-4 text-center"
                    style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="text-2xl mb-1">🔥</div>
                    <p className="font-bold text-xl" style={{ color: 'var(--accent)' }}>{overallStreak}</p>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Current Streak</p>
                  </div>
                  <div className="rounded-xl p-4 text-center"
                    style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                    <div className="text-2xl mb-1">🏆</div>
                    <p className="font-bold text-xl" style={{ color: 'var(--secondary)' }}>{allHabitsLongest}</p>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Longest Streak</p>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

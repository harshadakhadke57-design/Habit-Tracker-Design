import { useState } from 'react';
import { useApp } from '../store';
import type { User, UserType } from '../types';

const USER_TYPE_ORDER: UserType[] = [
  'Student', 'Fitness Enthusiast', 'Working Professional',
  'Senior/Elder', 'General User', 'Other',
];

const USER_TYPE_ICONS: Record<UserType, string> = {
  'Student': '🎓',
  'Fitness Enthusiast': '💪',
  'Working Professional': '💼',
  'Senior/Elder': '🌳',
  'General User': '👤',
  'Other': '✨',
};

export default function AdminScreen() {
  const { currentUser, users, habits, completions, suggestions, navigate } = useApp();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // Authorization check
  if (!currentUser?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6" style={{ background: 'var(--background)' }}>
        <div className="text-center">
          <div className="text-5xl mb-4">🔒</div>
          <h2 className="font-display font-bold text-xl mb-2" style={{ color: 'var(--foreground)' }}>
            Access Denied
          </h2>
          <p className="text-sm mb-5" style={{ color: 'var(--muted-foreground)' }}>
            You don't have permission to view this section.
          </p>
          <button onClick={() => navigate('home')}
            className="px-5 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>
            Go Home
          </button>
        </div>
      </div>
    );
  }

  // Group users by type (exclude passwords and secrets)
  const safeUsers = users.map(u => ({
    id: u.id, name: u.name, email: u.email,
    userType: u.userType, isAdmin: u.isAdmin, createdAt: u.createdAt,
  }));

  const groupedUsers = USER_TYPE_ORDER.reduce((acc, type) => {
    const group = safeUsers.filter(u => u.userType === type);
    if (group.length > 0) acc[type] = group;
    return acc;
  }, {} as Record<string, typeof safeUsers>);

  function getUserStats(userId: string) {
    const userHabits = habits.filter(h => h.userId === userId && h.active);
    const total = completions.filter(c => c.userId === userId && c.completed).length;
    const userSuggestions = suggestions.filter(s => s.userId === userId && !s.isDefault);
    return { habits: userHabits.length, completions: total, suggestions: userSuggestions.length };
  }

  function getUserSuggestions(userId: string) {
    return suggestions.filter(s => s.userId === userId && !s.isDefault);
  }

  if (selectedUser) {
    const stats = getUserStats(selectedUser.id);
    const userSuggestions = getUserSuggestions(selectedUser.id);

    return (
      <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
        <div className="px-5 pt-12 pb-5"
          style={{ background: 'linear-gradient(135deg, var(--accent) 0%, #C0411A 100%)' }}>
          <div className="max-w-sm mx-auto">
            <button onClick={() => setSelectedUser(null)}
              className="text-white opacity-70 text-sm mb-2">
              ← Users
            </button>
            <h1 className="font-display font-bold text-2xl text-white">{selectedUser.name}</h1>
          </div>
        </div>

        <div className="px-5 max-w-sm mx-auto pt-4">
          <div className="rounded-2xl p-4 mb-4"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="flex flex-col gap-2">
              <div className="flex justify-between">
                <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Email</span>
                <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>{selectedUser.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>User Type</span>
                <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                  {USER_TYPE_ICONS[selectedUser.userType as UserType]} {selectedUser.userType}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Role</span>
                <span className="text-sm font-medium" style={{ color: selectedUser.isAdmin ? 'var(--accent)' : 'var(--foreground)' }}>
                  {selectedUser.isAdmin ? '👑 Admin' : 'User'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Joined</span>
                <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                  {new Date(selectedUser.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            {[
              { label: 'Habits', value: stats.habits, icon: '🌱' },
              { label: 'Completions', value: stats.completions, icon: '✅' },
              { label: 'Suggestions', value: stats.suggestions, icon: '💡' },
            ].map(s => (
              <div key={s.label} className="rounded-xl p-3 text-center"
                style={{ background: 'var(--muted)' }}>
                <div className="text-xl">{s.icon}</div>
                <p className="font-bold text-lg" style={{ color: 'var(--foreground)' }}>{s.value}</p>
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{s.label}</p>
              </div>
            ))}
          </div>

          <h3 className="font-display font-bold text-base mb-3" style={{ color: 'var(--foreground)' }}>
            Submitted Suggestions
          </h3>
          {userSuggestions.length === 0 ? (
            <div className="text-center py-8 rounded-xl" style={{ background: 'var(--muted)' }}>
              <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>No suggestions submitted yet.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {userSuggestions.map(s => (
                <div key={s.id} className="rounded-xl p-3"
                  style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                  <p className="font-semibold text-sm" style={{ color: 'var(--foreground)' }}>{s.title}</p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{s.category}</p>
                  <p className="text-xs mt-1 leading-relaxed" style={{ color: 'var(--foreground)' }}>{s.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, var(--accent) 0%, #C0411A 100%)' }}>
        <div className="max-w-sm mx-auto">
          <button onClick={() => navigate('profile')}
            className="text-white opacity-70 text-sm mb-2">
            ← Profile
          </button>
          <h1 className="font-display font-bold text-2xl text-white">👑 Admin Panel</h1>
          <p className="text-white opacity-70 text-xs mt-1">
            {users.length} registered users
          </p>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto pt-4">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: 'Total Users', value: users.length, icon: '👥' },
            { label: 'Total Habits', value: habits.length, icon: '🌱' },
            { label: 'Suggestions', value: suggestions.filter(s => !s.isDefault).length, icon: '💡' },
          ].map(s => (
            <div key={s.label} className="rounded-xl p-3 text-center"
              style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <div className="text-xl">{s.icon}</div>
              <p className="font-bold text-xl" style={{ color: 'var(--foreground)' }}>{s.value}</p>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{s.label}</p>
            </div>
          ))}
        </div>

        {/* Users by type */}
        {Object.entries(groupedUsers).map(([type, typeUsers]) => (
          <div key={type} className="mb-5">
            <h2 className="font-display font-bold text-base mb-2 flex items-center gap-2"
              style={{ color: 'var(--foreground)' }}>
              <span>{USER_TYPE_ICONS[type as UserType]}</span>
              {type}
              <span className="text-xs font-normal px-2 py-0.5 rounded-full"
                style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>
                {typeUsers.length}
              </span>
            </h2>
            <div className="flex flex-col gap-2">
              {typeUsers.map(u => {
                const stats = getUserStats(u.id);
                return (
                  <button
                    key={u.id}
                    onClick={() => setSelectedUser(users.find(usr => usr.id === u.id) || null)}
                    className="rounded-2xl p-3.5 text-left flex items-center gap-3 transition-all"
                    style={{ background: 'var(--card)', border: '1px solid var(--border)' }}
                  >
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm flex-none"
                      style={{ background: 'linear-gradient(135deg, var(--primary), var(--secondary))', color: '#fff' }}>
                      {u.name.split(' ').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm" style={{ color: 'var(--foreground)' }}>
                        {u.name}
                        {u.isAdmin && <span className="ml-1 text-xs" style={{ color: 'var(--accent)' }}>👑</span>}
                      </p>
                      <p className="text-xs truncate" style={{ color: 'var(--muted-foreground)' }}>
                        {stats.habits} habits · {stats.completions} completions
                      </p>
                    </div>
                    <span style={{ color: 'var(--muted-foreground)' }}>›</span>
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {Object.keys(groupedUsers).length === 0 && (
          <div className="text-center py-12 rounded-2xl" style={{ background: 'var(--muted)' }}>
            <div className="text-4xl mb-3">👥</div>
            <p style={{ color: 'var(--muted-foreground)' }}>No users registered yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}

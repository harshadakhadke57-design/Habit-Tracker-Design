import { useMemo, useState } from 'react';
import { useApp, calculateOverallStreak } from '../store';
import type { User } from '../types';

export default function UserSearchScreen() {
  const { users, currentUser, habits, completions, showToast, navigate } = useApp();
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<User | null>(null);
  const [following, setFollowing] = useState<string[]>([]);
  const results = useMemo(() => users.filter(u => u.id !== currentUser?.id && `${u.name} ${u.username || ''}`.toLowerCase().includes(query.toLowerCase())), [currentUser, query, users]);

  function initials(name: string) { return name.split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase(); }

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      <div className="px-5 pt-12 pb-6" style={{ background: 'linear-gradient(135deg, var(--primary), #246D66)' }}><div className="max-w-sm mx-auto"><p className="text-xs text-white opacity-70">Community</p><h1 className="font-display font-bold text-2xl text-white">Search people</h1></div></div>
      <div className="px-5 max-w-sm mx-auto py-5">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search username or display name" className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none mb-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }} />
        {!results.length ? <div className="text-center py-16"><p className="font-semibold">No users found</p><p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>Try another username.</p></div> : results.map(user => <button key={user.id} onClick={() => setSelected(user)} className="w-full flex items-center gap-3 p-3 rounded-2xl mb-2 text-left" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}><span className="w-11 h-11 rounded-full grid place-items-center font-bold" style={{ background: 'var(--muted)', color: 'var(--primary)' }}>{initials(user.name)}</span><span><strong className="block text-sm">@{user.username || user.name.toLowerCase().replaceAll(' ', '')}</strong><small style={{ color: 'var(--muted-foreground)' }}>{user.name}</small></span></button>)}
      </div>
      {selected && (() => {
        const userHabits = habits.filter(h => h.userId === selected.id);
        const done = completions.filter(c => c.userId === selected.id && c.completed).length;
        const streak = calculateOverallStreak(selected.id, userHabits, completions);
        const own = selected.id === currentUser?.id;
        return <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center" style={{ background: 'rgba(0,0,0,.5)' }}><div className="w-full max-w-md rounded-t-3xl md:rounded-3xl p-6" style={{ background: 'var(--card)' }}><button onClick={() => setSelected(null)} className="float-right text-lg">×</button><div className="w-20 h-20 rounded-full grid place-items-center font-display font-bold text-2xl mb-3" style={{ background: 'var(--muted)', color: 'var(--primary)' }}>{initials(selected.name)}</div><h2 className="font-display font-bold text-2xl">{selected.name}</h2><p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>@{selected.username || selected.name.toLowerCase().replaceAll(' ', '')}</p><p className="my-4 text-sm">{selected.bio || 'Building better habits, one day at a time.'}</p><div className="grid grid-cols-3 gap-2 my-5 text-center">{[['Completed', done], ['Streak', streak], ['Followers', following.includes(selected.id) ? 1 : 0]].map(([l,v]) => <div key={l} className="p-3 rounded-xl" style={{ background: 'var(--muted)' }}><strong className="block">{v}</strong><small style={{ color: 'var(--muted-foreground)' }}>{l}</small></div>)}</div><div className="flex gap-2">{own ? <button onClick={() => navigate('profile')} className="landing-primary flex-1">Edit Profile</button> : <><button onClick={() => setFollowing(f => f.includes(selected.id) ? f.filter(x => x !== selected.id) : [...f, selected.id])} className="landing-primary flex-1">{following.includes(selected.id) ? 'Following' : 'Follow'}</button><button onClick={() => showToast('Messaging will be available soon.', 'info')} className="landing-secondary flex-1">Message</button></>}</div></div></div>;
      })()}
    </div>
  );
}

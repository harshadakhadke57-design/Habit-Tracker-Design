import { useState } from 'react';
import { useApp } from '../store';
import type { AppSettings } from '../types';

interface ToggleProps {
  value: boolean;
  onChange: (v: boolean) => void;
}

function Toggle({ value, onChange }: ToggleProps) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="w-11 h-6 rounded-full relative transition-colors flex-none"
      style={{ background: value ? 'var(--primary)' : 'var(--border)' }}
    >
      <span
        className="w-5 h-5 bg-white rounded-full absolute top-0.5 shadow-sm transition-all"
        style={{ left: value ? '22px' : '2px' }}
      />
    </button>
  );
}

interface SettingRowProps {
  icon: string;
  label: string;
  description?: string;
  children?: React.ReactNode;
}

function SettingRow({ icon, label, description, children }: SettingRowProps) {
  return (
    <div className="flex items-center justify-between py-3.5"
      style={{ borderBottom: '1px solid var(--border)' }}>
      <div className="flex items-center gap-3 flex-1">
        <span className="text-xl flex-none">{icon}</span>
        <div>
          <p className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>{label}</p>
          {description && (
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{description}</p>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

interface SectionProps {
  title: string;
  children: React.ReactNode;
}

function Section({ title, children }: SectionProps) {
  return (
    <div className="mb-5">
      <p className="text-xs font-semibold uppercase tracking-wider mb-1 px-1"
        style={{ color: 'var(--muted-foreground)' }}>
        {title}
      </p>
      <div className="rounded-2xl px-4"
        style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        {children}
      </div>
    </div>
  );
}

export default function SettingsScreen() {
  const { settings, updateSettings, logout, navigate, currentUser, showToast } = useApp();
  const [privacyChoice, setPrivacyChoice] = useState(settings.privacy);
  const [confirmPrivate, setConfirmPrivate] = useState(false);

  function handleTheme(theme: AppSettings['theme']) {
    updateSettings({ theme });
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', prefersDark);
    }
    showToast(`Theme set to ${theme}`, 'success');
  }

  function handleLogout() {
    logout();
    navigate('login');
    showToast('Logged out successfully.', 'info');
  }

  function savePrivacy() {
    if (privacyChoice === settings.privacy) return;
    if (privacyChoice === 'private') { setConfirmPrivate(true); return; }
    updateSettings({ privacy: privacyChoice });
    showToast('Privacy updated to Public.', 'success');
  }

  function confirmPrivacy() {
    updateSettings({ privacy: 'private' });
    setConfirmPrivate(false);
    showToast('Privacy updated to Private.', 'success');
  }

  async function handleNotifications(value: boolean) {
    if (value && 'Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        showToast('Notification permission was not granted.', 'error');
        return;
      }
    }
    updateSettings({ notificationsEnabled: value });
    showToast(`Notifications ${value ? 'enabled' : 'disabled'}`, 'info');
  }

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, #6B7B6A 0%, #4A5548 100%)' }}>
        <div className="max-w-sm mx-auto">
          <button onClick={() => navigate('profile')} className="text-white opacity-70 text-sm mb-2 flex items-center gap-1">
            ← Profile
          </button>
          <h1 className="font-display font-bold text-2xl text-white">Settings</h1>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto pt-5">
        {/* User info */}
        <div className="rounded-2xl p-4 mb-5 flex items-center gap-3"
          style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm"
            style={{ background: 'linear-gradient(135deg, var(--primary), var(--secondary))', color: '#fff' }}>
            {currentUser?.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2)}
          </div>
          <div>
            <p className="font-semibold text-sm" style={{ color: 'var(--foreground)' }}>{currentUser?.name}</p>
            <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{currentUser?.email}</p>
          </div>
        </div>

        {/* Notifications */}
        <Section title="Notifications">
          <SettingRow icon="🔔" label="Push Notifications" description="Receive app notifications">
            <Toggle
              value={settings.notificationsEnabled}
              onChange={handleNotifications}
            />
          </SettingRow>
          <SettingRow icon="⏰" label="Habit Reminders" description="Daily reminders for your habits">
            <Toggle
              value={settings.remindersEnabled}
              onChange={v => { updateSettings({ remindersEnabled: v }); showToast(`Reminders ${v ? 'enabled' : 'disabled'}`, 'info'); }}
            />
          </SettingRow>
        </Section>

        {/* Appearance */}
        <Section title="Appearance">
          <SettingRow icon="☀️" label="Theme" description="Choose your display theme">
            <div className="flex gap-1">
              {(['light', 'dark', 'system'] as AppSettings['theme'][]).map(t => (
                <button
                  key={t}
                  onClick={() => handleTheme(t)}
                  className="px-2 py-1 rounded-lg text-xs font-medium capitalize transition-all"
                  style={{
                    background: settings.theme === t ? 'var(--primary)' : 'var(--muted)',
                    color: settings.theme === t ? 'var(--primary-foreground)' : 'var(--muted-foreground)',
                  }}
                >
                  {t}
                </button>
              ))}
            </div>
          </SettingRow>
        </Section>

        {/* Account */}
        <Section title="Account">
          <SettingRow icon="👤" label="Edit Profile" description="Update your personal info">
            <button onClick={() => navigate('profile')} className="text-sm"
              style={{ color: 'var(--primary)' }}>Edit →</button>
          </SettingRow>
          <SettingRow icon="🌱" label="My Habits" description="Manage all your habits">
            <button onClick={() => navigate('habits')} className="text-sm"
              style={{ color: 'var(--primary)' }}>View →</button>
          </SettingRow>
        </Section>

        {/* Privacy */}
        <Section title="Account Privacy">
          <div className="py-4">
            <div className="grid gap-2">
              {([
                ['public', 'Public', 'Anyone can find you and view your profile, habits and streak.'],
                ['private', 'Private', "Only approved followers can see your profile details. You won't appear in search results."],
              ] as const).map(([value, label, description]) => {
                const selected = privacyChoice === value;
                return (
                  <button key={value} onClick={() => setPrivacyChoice(value)}
                    className="w-full p-3 rounded-xl text-left flex items-start gap-3 transition-all"
                    style={{ border: `1.5px solid ${selected ? 'var(--primary)' : 'var(--border)'}`, background: selected ? 'var(--muted)' : 'transparent' }}>
                    <span className="mt-0.5 w-5 h-5 rounded-full flex items-center justify-center flex-none"
                      style={{ border: `2px solid ${selected ? 'var(--primary)' : 'var(--border)'}` }}>
                      {selected && <span className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--primary)' }} />}
                    </span>
                    <span><span className="block text-sm font-semibold">{label}</span><span className="block text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{description}</span></span>
                    {selected && <span className="ml-auto" style={{ color: 'var(--primary)' }}>✓</span>}
                  </button>
                );
              })}
            </div>
            <button onClick={savePrivacy} disabled={privacyChoice === settings.privacy}
              className="w-full py-2.5 rounded-xl text-sm font-semibold mt-3 disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>Save changes</button>
          </div>
        </Section>

        <Section title="Privacy & Security">
          <SettingRow icon="🔒" label="Account Security" description="Your account session and local data are protected">
            <button onClick={() => showToast('Your account is secure.', 'success')} className="text-sm" style={{ color: 'var(--primary)' }}>Check</button>
          </SettingRow>
          <SettingRow icon="🛡️" label="Data Privacy" description="Review how your habit data is stored">
            <button onClick={() => showToast('Your habit data is stored only in this browser.', 'info')} className="text-sm" style={{ color: 'var(--primary)' }}>Review</button>
          </SettingRow>
        </Section>

        {/* Language */}
        <Section title="Language">
          <SettingRow icon="🌐" label="Language" description="Choose your interface language">
            <select value={settings.language} onChange={e => { updateSettings({ language: e.target.value as AppSettings['language'] }); showToast('Language preference saved.', 'success'); }}
              className="px-2 py-1.5 rounded-lg text-sm outline-none" style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1px solid var(--border)' }}>
              <option value="en">English</option><option value="es">Español</option><option value="fr">Français</option>
            </select>
          </SettingRow>
        </Section>

        {/* Help */}
        <Section title="Help & Support">
          <SettingRow icon="❓" label="FAQ" description="Frequently asked questions"><button onClick={() => showToast('Create a habit, then complete it daily to build a streak.', 'info')} className="text-sm" style={{ color: 'var(--primary)' }}>Open</button></SettingRow>
          <SettingRow icon="📧" label="Contact Support" description="support@habittracker.app"><button onClick={() => { window.location.href = 'mailto:support@habittracker.app'; }} className="text-sm" style={{ color: 'var(--primary)' }}>Email</button></SettingRow>
          <SettingRow icon="ℹ️" label="About" description="Habit Tracker v1.0.0"><button onClick={() => showToast('Habit Tracker v1.0.0', 'info')} className="text-sm" style={{ color: 'var(--primary)' }}>Info</button></SettingRow>
        </Section>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full py-4 rounded-2xl font-semibold text-base mt-2 mb-5 transition-all active:scale-95"
          style={{ background: '#FFF0EE', color: '#E53E3E', border: '1.5px solid #FED7D7' }}
        >
          🚪 Sign Out
        </button>
      </div>

      {confirmPrivate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5" style={{ background: 'rgba(0,0,0,.5)' }}>
          <div className="w-full max-w-sm rounded-2xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <h2 className="font-display font-bold text-lg">Switch to Private?</h2>
            <p className="text-sm mt-2 mb-5" style={{ color: 'var(--muted-foreground)' }}>Your profile will be hidden from search. Continue?</p>
            <div className="flex gap-2">
              <button onClick={() => setConfirmPrivate(false)} className="flex-1 py-2.5 rounded-xl text-sm font-medium" style={{ background: 'var(--muted)' }}>Cancel</button>
              <button onClick={confirmPrivacy} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}>Confirm</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

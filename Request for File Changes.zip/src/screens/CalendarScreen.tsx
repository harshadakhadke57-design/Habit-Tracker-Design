import { useState } from 'react';
import { useApp } from '../store';
import { CATEGORY_ICONS, CATEGORY_COLORS } from '../types';

function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number): number {
  return new Date(year, month, 1).getDay();
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const DAY_LABELS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export default function CalendarScreen() {
  const { currentUser, habits, completions } = useApp();
  const now = new Date();
  const [viewYear, setViewYear] = useState(now.getFullYear());
  const [viewMonth, setViewMonth] = useState(now.getMonth());
  const [selectedDate, setSelectedDate] = useState<string | null>(now.toISOString().split('T')[0]);
  const [dateError, setDateError] = useState('');

  if (!currentUser) return null;

  const userHabits = habits.filter(h => h.userId === currentUser.id && h.active);

  function getDayStatus(dateStr: string): 'full' | 'partial' | 'missed' | 'none' {
    const dayCompletions = completions.filter(c => c.userId === currentUser!.id && c.date === dateStr && c.completed);
    if (dayCompletions.length === 0) {
      // Check if any habits existed on that date
      const hasHabits = userHabits.some(h => h.startDate <= dateStr);
      if (!hasHabits) return 'none';
      // Don't mark future days as missed
      if (dateStr > now.toISOString().split('T')[0]) return 'none';
      return 'missed';
    }
    if (dayCompletions.length >= userHabits.length && userHabits.length > 0) return 'full';
    return 'partial';
  }

  function prevMonth() {
    if (viewYear === now.getFullYear() && viewMonth === now.getMonth()) return;
    if (viewMonth === 0) { setViewMonth(11); setViewYear(y => y - 1); }
    else setViewMonth(m => m - 1);
  }
  function nextMonth() {
    if (viewMonth === 11) { setViewMonth(0); setViewYear(y => y + 1); }
    else setViewMonth(m => m + 1);
  }

  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDay = getFirstDayOfMonth(viewYear, viewMonth);
  const today = now.toISOString().split('T')[0];
  const isCurrentMonth = viewYear === now.getFullYear() && viewMonth === now.getMonth();

  function selectDate(dateStr: string) {
    if (dateStr < today) {
      setDateError('Please select today or a future date.');
      return;
    }
    setDateError('');
    setSelectedDate(dateStr);
  }

  function goToToday() {
    setViewYear(now.getFullYear());
    setViewMonth(now.getMonth());
    setSelectedDate(today);
    setDateError('');
  }

  // Selected date details
  const selectedCompletions = selectedDate
    ? completions.filter(c => c.userId === currentUser.id && c.date === selectedDate && c.completed)
    : [];
  const selectedDoneHabits = userHabits.filter(h =>
    selectedCompletions.some(c => c.habitId === h.id)
  );
  const selectedMissedHabits = selectedDate && selectedDate <= today
    ? userHabits.filter(h =>
        h.startDate <= selectedDate &&
        !selectedCompletions.some(c => c.habitId === h.id)
      )
    : [];

  const statusColors: Record<string, string> = {
    full: 'var(--secondary)',
    partial: 'var(--primary)',
    missed: '#E8602C',
    none: 'transparent',
  };

  return (
    <div className="min-h-screen pb-24" style={{ background: 'var(--background)' }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-5"
        style={{ background: 'linear-gradient(135deg, #6B7FF0 0%, #4C5ED4 100%)' }}>
        <div className="max-w-sm mx-auto">
          <p className="text-xs text-white opacity-70 mb-0.5">Habit History</p>
          <h1 className="font-display font-bold text-2xl text-white">Calendar</h1>
        </div>
      </div>

      <div className="px-5 max-w-sm mx-auto">
        {/* Month navigation */}
        <div className="flex items-center justify-between my-4">
          <button
            onClick={prevMonth}
            disabled={isCurrentMonth}
            aria-label="Previous month"
            className="w-9 h-9 rounded-full flex items-center justify-center text-lg disabled:cursor-not-allowed disabled:opacity-40"
            style={{ background: 'var(--muted)', color: 'var(--foreground)' }}
          >
            ‹
          </button>
          <h2 className="font-display font-bold text-lg" style={{ color: 'var(--foreground)' }}>
            {MONTH_NAMES[viewMonth]} {viewYear}
          </h2>
          <button
            onClick={nextMonth}
            aria-label="Next month"
            className="w-9 h-9 rounded-full flex items-center justify-center text-lg"
            style={{ background: 'var(--muted)', color: 'var(--foreground)' }}
          >
            ›
          </button>
        </div>

        {/* Day labels */}
        <div className="grid grid-cols-7 mb-1">
          {DAY_LABELS.map(d => (
            <div key={d} className="text-center text-xs font-medium py-1" style={{ color: 'var(--muted-foreground)' }}>
              {d}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7 gap-1 mb-5">
          {/* Empty cells for first week */}
          {Array.from({ length: firstDay }).map((_, i) => <div key={`e${i}`} />)}

          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const dateStr = `${viewYear}-${String(viewMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const status = getDayStatus(dateStr);
            const isToday = dateStr === today;
            const isSelected = dateStr === selectedDate;
            const isPast = dateStr < today;
            const statusColor = statusColors[status];

            return (
              <button
                key={day}
                onClick={() => selectDate(dateStr)}
                disabled={isPast}
                aria-label={`${dateStr}${isPast ? ', unavailable' : ''}`}
                className="aspect-square rounded-full flex flex-col items-center justify-center relative transition-all enabled:hover:bg-indigo-50 disabled:cursor-not-allowed"
                style={{
                  background: isSelected ? 'var(--primary)' : isToday ? 'var(--muted)' : 'transparent',
                  border: isToday && !isSelected ? '1.5px solid var(--primary)' : '1.5px solid transparent',
                }}
              >
                <span className="text-sm font-medium"
                  style={{ color: isSelected ? '#fff' : isPast ? 'var(--border)' : isToday ? 'var(--primary)' : 'var(--foreground)' }}>
                  {day}
                </span>
                {status !== 'none' && (
                  <span
                    className="w-1.5 h-1.5 rounded-full absolute bottom-1"
                    style={{ background: isSelected ? 'rgba(255,255,255,0.8)' : statusColor }}
                  />
                )}
              </button>
            );
          })}
        </div>

        {dateError && (
          <p className="text-xs mb-3" role="alert" style={{ color: '#E8602C' }}>
            {dateError}
          </p>
        )}

        <div className="flex gap-3 mb-5">
          <button
            onClick={goToToday}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: 'var(--muted)', color: 'var(--primary)', border: '1px solid var(--border)' }}
          >
            Today
          </button>
          <button
            onClick={() => setDateError('')}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
          >
            Confirm
          </button>
        </div>

        {/* Legend */}
        <div className="flex gap-4 mb-5 flex-wrap">
          {[
            { color: 'var(--secondary)', label: 'All done' },
            { color: 'var(--primary)', label: 'Partial' },
            { color: '#E8602C', label: 'Missed' },
          ].map(item => (
            <div key={item.label} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: item.color }} />
              <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{item.label}</span>
            </div>
          ))}
        </div>

        {/* Selected date detail */}
        {selectedDate && (
          <div className="rounded-2xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <h3 className="font-display font-bold text-base mb-3" style={{ color: 'var(--foreground)' }}>
              {new Date(selectedDate + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </h3>

            {selectedDoneHabits.length === 0 && selectedMissedHabits.length === 0 ? (
              <p className="text-sm text-center py-4" style={{ color: 'var(--muted-foreground)' }}>
                No habit activity recorded for this date.
              </p>
            ) : (
              <>
                {selectedDoneHabits.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs font-semibold mb-2" style={{ color: 'var(--secondary)' }}>
                      ✅ Completed
                    </p>
                    <div className="flex flex-col gap-1.5">
                      {selectedDoneHabits.map(h => (
                        <div key={h.id} className="flex items-center gap-2">
                          <span>{CATEGORY_ICONS[h.category]}</span>
                          <span className="text-sm" style={{ color: 'var(--foreground)' }}>{h.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {selectedMissedHabits.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold mb-2" style={{ color: '#E8602C' }}>
                      ❌ Missed
                    </p>
                    <div className="flex flex-col gap-1.5">
                      {selectedMissedHabits.map(h => (
                        <div key={h.id} className="flex items-center gap-2">
                          <span style={{ filter: 'grayscale(1)', opacity: 0.5 }}>{CATEGORY_ICONS[h.category]}</span>
                          <span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{h.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

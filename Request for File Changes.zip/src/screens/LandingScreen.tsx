import { useState } from 'react';
import { useApp } from '../store';
import { LogoMark } from '../components/AppLogo';

const features = [
  ['✓', 'Simple daily tracking', 'Check off habits in seconds and keep your day focused.'],
  ['↗', 'Meaningful progress', 'See streaks, trends and milestones without unnecessary complexity.'],
  ['◷', 'Flexible reminders', 'Create routines that fit your schedule and adjust as life changes.'],
];

export default function LandingScreen() {
  const { navigate, currentUser } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const dashboard = () => navigate(currentUser ? 'home' : 'login');

  function goTo(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  }

  return (
    <div className="landing-page min-h-screen" style={{ background: 'var(--background)' }}>
      <header className="landing-nav">
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2.5">
          <LogoMark size={38} />
          <span className="font-display font-bold text-xl">HabitTracker</span>
        </button>
        <nav className="landing-links">
          <button onClick={() => goTo('features')}>Features</button>
          <button onClick={() => goTo('how-it-works')}>How it works</button>
          <button onClick={() => goTo('about')}>About</button>
        </nav>
        <div className="landing-actions">
          {currentUser ? (
            <button onClick={dashboard} className="landing-primary">Open Dashboard</button>
          ) : (
            <>
              <button onClick={() => navigate('login')} className="landing-secondary">Login</button>
              <button onClick={() => navigate('signup')} className="landing-primary">Register</button>
            </>
          )}
        </div>
        <button onClick={() => setMenuOpen(!menuOpen)} className="landing-menu" aria-label="Toggle navigation">
          <span /><span /><span />
        </button>
        {menuOpen && (
          <div className="landing-mobile-panel">
            <button onClick={() => goTo('features')}>Features</button>
            <button onClick={() => goTo('how-it-works')}>How it works</button>
            <button onClick={() => goTo('about')}>About</button>
            <button onClick={() => navigate('login')}>Login</button>
            <button onClick={() => navigate('signup')} className="landing-primary">Register</button>
          </div>
        )}
      </header>

      <main>
        <section className="landing-hero">
          <div className="landing-hero-copy">
            <span className="landing-eyebrow">Small steps. Lasting change.</span>
            <h1>Build better habits, one day at a time</h1>
            <p>Turn your goals into simple daily routines, stay consistent, and see your progress grow.</p>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => navigate(currentUser ? 'home' : 'signup')} className="landing-primary landing-large">
                {currentUser ? 'Open Dashboard' : 'Get Started'}
              </button>
              {!currentUser && <button onClick={() => navigate('login')} className="landing-secondary landing-large">Login</button>}
            </div>
            <div className="landing-proof"><strong>Free to start</strong><span>No credit card required</span><span>Works on every device</span></div>
          </div>
          <div className="landing-preview" aria-label="Habit dashboard preview">
            <div className="flex items-center justify-between mb-6">
              <div><p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>TODAY</p><p className="font-display font-bold text-xl">Your daily rhythm</p></div>
              <span className="landing-score">75%</span>
            </div>
            {['Morning stretch', 'Read for 20 minutes', 'Drink 8 glasses of water', 'Evening reflection'].map((habit, i) => (
              <div key={habit} className="landing-habit">
                <span className={i < 3 ? 'done' : ''}>{i < 3 ? '✓' : ''}</span>
                <div className="flex-1"><p className="font-semibold text-sm">{habit}</p><p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{i < 3 ? 'Completed today' : 'Up next'}</p></div>
                <small>{i < 3 ? `${i + 3} day streak` : '8:30 PM'}</small>
              </div>
            ))}
          </div>
        </section>

        <section id="features" className="landing-section">
          <div className="landing-section-heading"><span>EVERYTHING YOU NEED</span><h2>Consistency made simple</h2><p>Thoughtful tools that help you focus on progress instead of perfection.</p></div>
          <div className="landing-feature-grid">
            {features.map(([icon, title, body]) => <article key={title}><b>{icon}</b><h3>{title}</h3><p>{body}</p></article>)}
          </div>
        </section>

        <section id="how-it-works" className="landing-section landing-how">
          <div className="landing-section-heading"><span>HOW IT WORKS</span><h2>Three steps to a stronger routine</h2></div>
          <div className="landing-step-grid">
            {[
              ['01', 'Choose a habit', 'Start with one clear action that matters to you.'],
              ['02', 'Show up daily', 'Use reminders and quick check-ins to stay on track.'],
              ['03', 'Celebrate progress', 'Watch your streaks and achievements build over time.'],
            ].map(([n, title, body]) => <article key={n}><span>{n}</span><h3>{title}</h3><p>{body}</p></article>)}
          </div>
        </section>

        <section id="about" className="landing-cta">
          <LogoMark size={52} />
          <h2>Your next good habit starts today</h2>
          <p>Create a routine that feels achievable and build momentum one check-in at a time.</p>
          <button onClick={() => navigate(currentUser ? 'home' : 'signup')} className="landing-primary landing-large">
            {currentUser ? 'Go to Dashboard' : 'Create your free account'}
          </button>
        </section>
      </main>

      <footer className="landing-footer">
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2"><LogoMark size={28} /><strong>HabitTracker</strong></button>
        <p>Build better habits. Live better.</p>
        <p>© {new Date().getFullYear()} HabitTracker</p>
      </footer>
    </div>
  );
}

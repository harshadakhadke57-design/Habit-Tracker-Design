import { useState } from 'react';
import { useApp } from '../store';
import { USER_TYPES } from '../types';
import type { UserType } from '../types';
import AppLogo from '../components/AppLogo';

export default function SignupScreen() {
  const { signup, navigate, showToast } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [userType, setUserType] = useState<UserType | ''>('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  function handleSignup(e: React.FormEvent) {
    e.preventDefault();

    if (!name.trim()) { showToast('Name cannot be empty.', 'error'); return; }
    if (!email.trim()) { showToast('Email is required.', 'error'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showToast('Please enter a valid email address.', 'error'); return; }
    if (!password) { showToast('Password is required.', 'error'); return; }
    if (password.length < 6) { showToast('Password must be at least 6 characters.', 'error'); return; }
    if (password !== confirmPw) { showToast('Passwords do not match.', 'error'); return; }
    if (!userType) { showToast('Please select a user type.', 'error'); return; }

    setLoading(true);
    setTimeout(() => {
      const err = signup(name.trim(), email.trim().toLowerCase(), password, userType as UserType);
      setLoading(false);
      if (err) {
        showToast(err, 'error');
      } else {
        showToast('Account created successfully! 🎉', 'success');
        navigate('login');
      }
    }, 700);
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--background)' }}>
      <div className="flex-none py-8 flex flex-col items-center"
        style={{ background: 'linear-gradient(160deg, #E8F5F2 0%, var(--background) 100%)' }}>
        <button onClick={() => navigate('landing')} aria-label="Back to home">
          <AppLogo size="md" showText />
        </button>
      </div>

      <div className="flex-1 px-6 pt-2 pb-8 animate-fadeIn max-w-sm w-full mx-auto">
        <h2 className="font-display font-bold text-2xl mb-1" style={{ color: 'var(--foreground)' }}>
          Create account
        </h2>
        <p className="text-sm mb-5" style={{ color: 'var(--muted-foreground)' }}>
          Start your habit journey today ❤️
        </p>

        <form onSubmit={handleSignup} className="flex flex-col gap-3.5">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Full Name *
            </label>
            <input
              type="text"
              autoComplete="name"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Your full name"
              className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none"
              style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
            />
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Email *
            </label>
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none"
              style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Password *
            </label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                autoComplete="new-password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Min. 6 characters"
                className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none pr-12"
                style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              <button type="button" onClick={() => setShowPw(!showPw)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs"
                style={{ color: 'var(--muted-foreground)' }}>
                {showPw ? '🙈' : '👁️'}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              Confirm Password *
            </label>
            <input
              type="password"
              autoComplete="new-password"
              value={confirmPw}
              onChange={e => setConfirmPw(e.target.value)}
              placeholder="Repeat password"
              className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none"
              style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
            />
          </div>

          {/* User Type */}
          <div>
            <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
              I am a... *
            </label>
            <div className="grid grid-cols-2 gap-2">
              {USER_TYPES.map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setUserType(type)}
                  className="px-3 py-2.5 rounded-xl text-xs font-medium text-center transition-all"
                  style={{
                    background: userType === type ? 'var(--primary)' : 'var(--muted)',
                    color: userType === type ? 'var(--primary-foreground)' : 'var(--foreground)',
                    border: userType === type ? '1.5px solid var(--primary)' : '1.5px solid var(--border)',
                  }}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 rounded-2xl font-semibold text-base mt-2 transition-all active:scale-95"
            style={{
              background: loading ? 'var(--muted)' : 'var(--secondary)',
              color: loading ? 'var(--muted-foreground)' : 'var(--secondary-foreground)',
            }}
          >
            {loading ? 'Creating account...' : 'Create Account 🎉'}
          </button>
        </form>

        <div className="mt-5 text-center">
          <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
            Already have an account?{' '}
            <button onClick={() => navigate('login')} className="font-semibold" style={{ color: 'var(--primary)' }}>
              Sign in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

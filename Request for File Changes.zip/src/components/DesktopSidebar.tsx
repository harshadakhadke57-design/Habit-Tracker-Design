import { useApp } from '../store';
import type { Screen } from '../types';
import { LogoMark } from './AppLogo';

const ITEMS: { screen: Screen; label: string; symbol: string }[] = [
  { screen: 'home', label: 'Home', symbol: 'H' },
  { screen: 'habits', label: 'Habits', symbol: '✓' },
  { screen: 'calendar', label: 'Calendar', symbol: 'C' },
  { screen: 'progress', label: 'Progress', symbol: 'P' },
  { screen: 'history', label: 'History', symbol: 'R' },
  { screen: 'search', label: 'Search', symbol: '⌕' },
  { screen: 'suggestions', label: 'Discover', symbol: 'D' },
  { screen: 'profile', label: 'Profile', symbol: 'U' },
  { screen: 'settings', label: 'Settings', symbol: 'S' },
];

export default function DesktopSidebar() {
  const { screen, navigate, logout, currentUser } = useApp();

  return (
    <aside className="desktop-sidebar">
      <button onClick={() => navigate('landing')} className="flex items-center gap-3 px-3 mb-8 text-left">
        <LogoMark size={36} />
        <div>
          <p className="font-display font-bold text-lg">Habit Tracker</p>
          <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Build better days</p>
        </div>
      </button>

      <nav className="flex flex-col gap-1">
        {ITEMS.map(item => {
          const active = screen === item.screen;
          return (
            <button
              key={item.screen}
              onClick={() => navigate(item.screen)}
              className="flex items-center gap-3 w-full px-3 py-3 rounded-xl text-sm font-medium text-left transition-all"
              style={{
                background: active ? 'var(--primary)' : 'transparent',
                color: active ? 'var(--primary-foreground)' : 'var(--foreground)',
              }}
            >
              <span className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold"
                style={{ background: active ? 'rgba(255,255,255,.16)' : 'var(--muted)' }}>
                {item.symbol}
              </span>
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto pt-5" style={{ borderTop: '1px solid var(--border)' }}>
        <p className="px-3 text-sm font-semibold truncate">{currentUser?.name}</p>
        <p className="px-3 text-xs truncate mb-3" style={{ color: 'var(--muted-foreground)' }}>{currentUser?.email}</p>
        <button
          onClick={() => { logout(); navigate('login'); }}
          className="w-full px-3 py-2.5 rounded-xl text-left text-sm font-medium"
          style={{ color: '#C43D3D', background: 'var(--muted)' }}
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}

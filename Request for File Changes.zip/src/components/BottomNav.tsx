import { useApp } from '../store';
import type { Screen } from '../types';

interface NavItem {
  screen: Screen;
  icon: string;
  label: string;
}

const NAV_ITEMS: NavItem[] = [
  { screen: 'home', icon: '🏠', label: 'Home' },
  { screen: 'habits', icon: '✅', label: 'Habits' },
  { screen: 'calendar', icon: '📅', label: 'Calendar' },
  { screen: 'progress', icon: '📊', label: 'Progress' },
  { screen: 'profile', icon: '👤', label: 'Profile' },
];

export default function BottomNav() {
  const { screen, navigate } = useApp();

  return (
    <nav className="mobile-nav fixed bottom-0 left-0 right-0 z-40 safe-bottom" style={{ background: 'var(--card)', borderTop: '1px solid var(--border)' }}>
      <div className="max-w-sm mx-auto flex justify-around items-center py-2">
        {NAV_ITEMS.map(item => {
          const active = screen === item.screen;
          return (
            <button
              key={item.screen}
              onClick={() => navigate(item.screen)}
              className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-xl transition-all"
              style={{ color: active ? 'var(--primary)' : 'var(--muted-foreground)' }}
            >
              <span className="text-xl leading-none" style={{ transform: active ? 'scale(1.15)' : 'scale(1)', transition: 'transform 0.2s' }}>
                {item.icon}
              </span>
              <span className="text-xs font-medium" style={{ fontWeight: active ? 600 : 400 }}>
                {item.label}
              </span>
              {active && (
                <span className="w-1 h-1 rounded-full" style={{ background: 'var(--primary)' }} />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

import habitLogoSrc from '../assets/habits-logo.png';

interface AppLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

const sizes = {
  sm: 40,
  md: 64,
  lg: 96,
  xl: 140,
};

export default function AppLogo({ size = 'md', showText = false, className = '' }: AppLogoProps) {
  const px = sizes[size];

  return (
    <div className={`flex flex-col items-center gap-2 ${className}`}>
      <img
        src={habitLogoSrc}
        alt="Habit Tracker Logo"
        width={px}
        height={px}
        style={{ width: px, height: px, objectFit: 'contain' }}
        className="drop-shadow-md"
      />
      {showText && (
        <div className="text-center">
          <p className="font-display font-bold text-foreground" style={{ fontSize: size === 'xl' ? 28 : 20, letterSpacing: '-0.02em' }}>
            Habit Tracker
          </p>
          {size === 'xl' && (
            <p className="text-muted-foreground text-sm mt-1">Build Better Habits. Live Better. ❤️</p>
          )}
        </div>
      )}
    </div>
  );
}

/** Compact logo mark for use in app header */
export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <img
      src={habitLogoSrc}
      alt="Habit Tracker"
      width={size}
      height={size}
      style={{ width: size, height: size, objectFit: 'contain' }}
      className="drop-shadow-sm"
    />
  );
}

import { useState, useEffect } from 'react';
import { useApp } from '../store';
import { HABIT_CATEGORIES, USER_TYPES } from '../types';
import type { HabitCategory, HabitFrequency, Habit } from '../types';

interface Props {
  onClose: () => void;
  editingHabit?: Habit | null;
}

export default function CreateHabitModal({ onClose, editingHabit }: Props) {
  const { createHabit, updateHabit, showToast } = useApp();

  const [name, setName] = useState(editingHabit?.name ?? '');
  const [description, setDescription] = useState(editingHabit?.description ?? '');
  const [category, setCategory] = useState<HabitCategory>(editingHabit?.category ?? 'Fitness');
  const [frequency, setFrequency] = useState<HabitFrequency>(editingHabit?.frequency ?? 'Daily');
  const [target, setTarget] = useState(editingHabit?.target ?? '');
  const [startDate, setStartDate] = useState(editingHabit?.startDate ?? new Date().toISOString().split('T')[0]);
  const [dateError, setDateError] = useState('');
  const [reminderEnabled, setReminderEnabled] = useState(editingHabit?.reminderEnabled ?? false);
  const [reminderTime, setReminderTime] = useState(editingHabit?.reminderTime ?? '08:00');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Please enter a habit name', 'error');
      return;
    }
    if (!target.trim()) {
      showToast('Please enter a target', 'error');
      return;
    }
    const today = new Date().toISOString().split('T')[0];
    if (startDate < today) {
      setDateError('Please select today or a future date.');
      return;
    }

    if (editingHabit) {
      updateHabit(editingHabit.id, { name, description, category, frequency, target, startDate, reminderEnabled, reminderTime });
      showToast('Habit updated! 🎯', 'success');
    } else {
      createHabit({ name, description, category, frequency, target, startDate, reminderEnabled, reminderTime });
      showToast('Habit created successfully! 🎯', 'success');
    }
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-sm rounded-t-3xl animate-slideUp"
        style={{ background: 'var(--background)', maxHeight: '90vh', overflowY: 'auto' }}>
        <div className="px-6 py-5">
          {/* Handle */}
          <div className="w-10 h-1 rounded-full mx-auto mb-4" style={{ background: 'var(--border)' }} />

          <div className="flex items-center justify-between mb-5">
            <h2 className="font-display font-bold text-xl" style={{ color: 'var(--foreground)' }}>
              {editingHabit ? 'Edit Habit' : 'Create New Habit'}
            </h2>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-full"
              style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>
              ✕
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Habit Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Morning Run"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Description
              </label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="What does this habit involve?"
                rows={2}
                className="w-full px-4 py-3 rounded-xl text-sm outline-none resize-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Category *
              </label>
              <div className="grid grid-cols-2 gap-2">
                {HABIT_CATEGORIES.map(cat => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className="px-3 py-2 rounded-xl text-xs font-medium text-left transition-all"
                    style={{
                      background: category === cat ? 'var(--primary)' : 'var(--muted)',
                      color: category === cat ? 'var(--primary-foreground)' : 'var(--foreground)',
                      border: category === cat ? '1.5px solid var(--primary)' : '1.5px solid var(--border)',
                    }}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Frequency */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Frequency *
              </label>
              <div className="flex gap-2">
                {(['Daily', 'Weekly', 'Custom'] as HabitFrequency[]).map(freq => (
                  <button
                    key={freq}
                    type="button"
                    onClick={() => setFrequency(freq)}
                    className="flex-1 py-2.5 rounded-xl text-sm font-medium transition-all"
                    style={{
                      background: frequency === freq ? 'var(--primary)' : 'var(--muted)',
                      color: frequency === freq ? 'var(--primary-foreground)' : 'var(--foreground)',
                    }}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>

            {/* Target */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Target *
              </label>
              <input
                type="text"
                value={target}
                onChange={e => setTarget(e.target.value)}
                placeholder="e.g. Run 30 minutes"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
            </div>

            {/* Start Date */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--muted-foreground)' }}>
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={e => {
                  setStartDate(e.target.value);
                  setDateError(e.target.value < new Date().toISOString().split('T')[0]
                    ? 'Please select today or a future date.'
                    : '');
                }}
                className="w-full px-4 py-3 rounded-xl text-sm outline-none"
                style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
              />
              {dateError && (
                <p className="text-xs mt-1.5" role="alert" style={{ color: '#E8602C' }}>
                  {dateError}
                </p>
              )}
            </div>

            {/* Reminder */}
            <div className="rounded-xl p-4" style={{ background: 'var(--muted)', border: '1.5px solid var(--border)' }}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>Set Reminder</span>
                <button
                  type="button"
                  onClick={() => setReminderEnabled(!reminderEnabled)}
                  className="w-11 h-6 rounded-full relative transition-colors"
                  style={{ background: reminderEnabled ? 'var(--primary)' : 'var(--border)' }}
                >
                  <span className="w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all"
                    style={{ left: reminderEnabled ? '22px' : '2px' }} />
                </button>
              </div>
              {reminderEnabled && (
                <input
                  type="time"
                  value={reminderTime}
                  onChange={e => setReminderTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                  style={{ background: 'var(--card)', color: 'var(--foreground)', border: '1.5px solid var(--border)' }}
                />
              )}
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-2xl font-semibold text-base mt-2 transition-all active:scale-95"
              style={{ background: 'var(--primary)', color: 'var(--primary-foreground)' }}
            >
              {editingHabit ? 'Save Changes' : 'Create Habit 🎯'}
            </button>
          </form>
        </div>
        <div className="h-8" />
      </div>
    </div>
  );
}

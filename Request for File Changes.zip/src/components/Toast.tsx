import { useEffect } from 'react';
import { useApp } from '../store';
import type { ToastMessage } from '../types';

function SingleToast({ toast }: { toast: ToastMessage }) {
  const { dismissToast } = useApp();

  useEffect(() => {
    const t = setTimeout(() => dismissToast(toast.id), 3500);
    return () => clearTimeout(t);
  }, [toast.id, dismissToast]);

  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const colors = {
    success: 'bg-secondary text-white',
    error: 'bg-red-500 text-white',
    info: 'bg-primary text-white',
  };

  return (
    <div
      className={`flex items-center gap-3 px-4 py-3 rounded-2xl shadow-lg max-w-xs text-sm font-medium animate-toastIn ${colors[toast.type]}`}
      onClick={() => dismissToast(toast.id)}
    >
      <span>{icons[toast.type]}</span>
      <span className="flex-1">{toast.message}</span>
    </div>
  );
}

export default function ToastContainer() {
  const { toasts } = useApp();
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 items-center pointer-events-none">
      {toasts.map(t => (
        <div key={t.id} className="pointer-events-auto">
          <SingleToast toast={t} />
        </div>
      ))}
    </div>
  );
}

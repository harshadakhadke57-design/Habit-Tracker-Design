import { useState, useCallback, useEffect } from 'react';
import {
  AppContext,
  loadInitialState,
  simpleHash,
  generateId,
  persistUsers,
  persistHabits,
  persistCompletions,
  persistSuggestions,
  persistSettings,
  persistCurrentUser,
  useApp,
} from './store';
import type { AppState, AppContextValue } from './store';
import type {
  User, Habit, HabitCompletion, HabitSuggestion,
  AppSettings, ToastMessage, Screen, UserType,
} from './types';

import SplashScreen from './screens/SplashScreen';
import LandingScreen from './screens/LandingScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import HomeScreen from './screens/HomeScreen';
import HabitsScreen from './screens/HabitsScreen';
import CalendarScreen from './screens/CalendarScreen';
import ProgressScreen from './screens/ProgressScreen';
import ProfileScreen from './screens/ProfileScreen';
import SettingsScreen from './screens/SettingsScreen';
import SuggestionsScreen from './screens/SuggestionsScreen';
import AdminScreen from './screens/AdminScreen';
import HistoryScreen from './screens/HistoryScreen';
import UserSearchScreen from './screens/UserSearchScreen';
import BottomNav from './components/BottomNav';
import ToastContainer from './components/Toast';
import DesktopSidebar from './components/DesktopSidebar';

const MAIN_SCREENS: Screen[] = ['home', 'habits', 'calendar', 'progress', 'profile'];

function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(loadInitialState);

  // Apply saved theme on mount
  useEffect(() => {
    const { theme } = state.settings;
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (theme === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', dark);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const navigate = useCallback((screen: Screen) => {
    setState(s => ({ ...s, screen }));
  }, []);

  const showToast = useCallback((message: string, type: ToastMessage['type'] = 'info') => {
    const id = generateId();
    setState(s => ({ ...s, toasts: [...s.toasts, { id, message, type }] }));
  }, []);

  const dismissToast = useCallback((id: string) => {
    setState(s => ({ ...s, toasts: s.toasts.filter(t => t.id !== id) }));
  }, []);

  const login = useCallback((email: string, password: string): string | null => {
    const users = JSON.parse(localStorage.getItem('ht_users') || '[]') as User[];
    const user = users.find(u => u.email === email);
    if (!user) return 'Invalid email or password. Please try again.';
    const hash = simpleHash(password);
    if (user.passwordHash !== hash) return 'Invalid email or password. Please try again.';
    persistCurrentUser(user.id);
    setState(s => ({ ...s, currentUser: user, users, screen: 'home' }));
    return null;
  }, []);

  const signup = useCallback((
    name: string, email: string, password: string, userType: UserType
  ): string | null => {
    const users = JSON.parse(localStorage.getItem('ht_users') || '[]') as User[];
    if (users.find(u => u.email === email)) {
      return 'An account with this email already exists.';
    }
    const isFirst = users.length === 0;
    const newUser: User = {
      id: generateId(), name, email,
      passwordHash: simpleHash(password),
      username: email.split('@')[0].replace(/[^a-z0-9._]/gi, '').toLowerCase(),
      bio: '',
      userType, isAdmin: isFirst,
      createdAt: new Date().toISOString(),
    };
    const updated = [...users, newUser];
    persistUsers(updated);
    persistCurrentUser(null);
    setState(s => ({ ...s, currentUser: null, users: updated, screen: 'login' }));
    return null;
  }, []);

  const logout = useCallback(() => {
    persistCurrentUser(null);
    setState(s => ({ ...s, currentUser: null, screen: 'login' }));
  }, []);

  const createHabit = useCallback((data: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'active'>) => {
    setState(s => {
      if (!s.currentUser) return s;
      const newHabit: Habit = {
        ...data, id: generateId(),
        userId: s.currentUser.id,
        active: true, createdAt: new Date().toISOString(),
      };
      const updated = [...s.habits, newHabit];
      persistHabits(updated);
      return { ...s, habits: updated };
    });
  }, []);

  const updateHabit = useCallback((id: string, data: Partial<Habit>) => {
    setState(s => {
      const updated = s.habits.map(h => h.id === id ? { ...h, ...data } : h);
      persistHabits(updated);
      return { ...s, habits: updated };
    });
  }, []);

  const deleteHabit = useCallback((id: string) => {
    setState(s => {
      const habits = s.habits.filter(h => h.id !== id);
      const completions = s.completions.filter(c => c.habitId !== id);
      persistHabits(habits);
      persistCompletions(completions);
      return { ...s, habits, completions };
    });
  }, []);

  const completeHabit = useCallback((habitId: string, date: string): boolean => {
    let success = false;
    setState(s => {
      if (!s.currentUser) return s;
      const already = s.completions.some(
        c => c.habitId === habitId && c.date === date && c.completed && c.userId === s.currentUser!.id
      );
      if (already) {
        success = false;
        return s;
      }
      const completion: HabitCompletion = {
        id: generateId(), userId: s.currentUser.id,
        habitId, date, completed: true,
        completedAt: new Date().toISOString(),
      };
      const updated = [...s.completions, completion];
      persistCompletions(updated);
      success = true;
      return { ...s, completions: updated };
    });
    return success;
  }, []);

  const addSuggestion = useCallback((
    data: Omit<HabitSuggestion, 'id' | 'userId' | 'userName' | 'createdAt' | 'status' | 'isDefault'>
  ) => {
    setState(s => {
      if (!s.currentUser) return s;
      const newSuggestion: HabitSuggestion = {
        ...data, id: generateId(),
        userId: s.currentUser.id,
        userName: s.currentUser.name,
        createdAt: new Date().toISOString(),
        status: 'approved', isDefault: false,
      };
      const updated = [...s.suggestions, newSuggestion];
      persistSuggestions(updated);
      return { ...s, suggestions: updated };
    });
  }, []);

  const updateSettings = useCallback((data: Partial<AppSettings>) => {
    setState(s => {
      const updated = { ...s.settings, ...data };
      persistSettings(updated);
      return { ...s, settings: updated };
    });
  }, []);

  const updateUser = useCallback((id: string, data: Partial<User>) => {
    setState(s => {
      const users = s.users.map(u => u.id === id ? { ...u, ...data } : u);
      const currentUser = s.currentUser?.id === id
        ? ({ ...s.currentUser, ...data } as User)
        : s.currentUser;
      persistUsers(users);
      return { ...s, users, currentUser };
    });
  }, []);

  const setEditingHabit = useCallback((habit: Habit | null) => {
    setState(s => ({ ...s, editingHabit: habit }));
  }, []);

  const value: AppContextValue = {
    ...state,
    navigate, login, signup, logout,
    createHabit, updateHabit, deleteHabit, completeHabit,
    addSuggestion, updateSettings, updateUser,
    showToast, dismissToast, setEditingHabit,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

function AppRoot() {
  const { screen, currentUser } = useApp();
  const isMainScreen = MAIN_SCREENS.includes(screen);
  const isPublicScreen = screen === 'landing' || screen === 'login' || screen === 'signup' || screen === 'splash';

  return (
    <div className="app-shell min-h-screen" style={{ background: 'var(--background)' }}>
      {currentUser && !isPublicScreen && <DesktopSidebar />}
      <main className={currentUser && !isPublicScreen ? 'desktop-content' : screen === 'landing' ? 'landing-content' : 'auth-content'}>
        {screen === 'splash' && <SplashScreen />}
        {screen === 'landing' && <LandingScreen />}
        {screen === 'login' && <LoginScreen />}
        {screen === 'signup' && <SignupScreen />}
        {screen === 'home' && <HomeScreen />}
        {screen === 'habits' && <HabitsScreen />}
        {screen === 'calendar' && <CalendarScreen />}
        {screen === 'progress' && <ProgressScreen />}
        {screen === 'history' && <HistoryScreen />}
        {screen === 'search' && <UserSearchScreen />}
        {screen === 'profile' && <ProfileScreen />}
        {screen === 'settings' && <SettingsScreen />}
        {screen === 'suggestions' && <SuggestionsScreen />}
        {screen === 'admin' && <AdminScreen />}
      </main>

      {currentUser && isMainScreen && <BottomNav />}
      <ToastContainer />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppRoot />
    </AppProvider>
  );
}

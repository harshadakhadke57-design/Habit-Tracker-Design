import { createContext, useContext } from 'react';
import type {
  User, Habit, HabitCompletion, HabitSuggestion, AppSettings, ToastMessage, Screen,
} from './types';

// --- Utilities ---

export function getTodayStr(): string {
  return new Date().toISOString().split('T')[0];
}

export function getDateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

export function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36) + str.length.toString(36);
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

export function calculateCurrentStreak(habitId: string, completions: HabitCompletion[]): number {
  const completedDates = new Set(
    completions.filter(c => c.habitId === habitId && c.completed).map(c => c.date)
  );
  if (completedDates.size === 0) return 0;

  let streak = 0;
  // Start from today; if today not done, allow grace from yesterday
  let startDaysAgo = completedDates.has(getTodayStr()) ? 0 : 1;

  for (let i = startDaysAgo; i < 365; i++) {
    if (completedDates.has(getDateStr(i))) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

export function calculateLongestStreak(habitId: string, completions: HabitCompletion[]): number {
  const dates = completions
    .filter(c => c.habitId === habitId && c.completed)
    .map(c => c.date)
    .sort();

  if (dates.length === 0) return 0;

  let longest = 1;
  let current = 1;

  for (let i = 1; i < dates.length; i++) {
    const prev = new Date(dates[i - 1]);
    const curr = new Date(dates[i]);
    const diff = (curr.getTime() - prev.getTime()) / 86400000;
    if (diff === 1) {
      current++;
      longest = Math.max(longest, current);
    } else {
      current = 1;
    }
  }
  return longest;
}

export function calculateOverallStreak(userId: string, habits: Habit[], completions: HabitCompletion[]): number {
  const userHabits = habits.filter(h => h.userId === userId && h.active);
  if (userHabits.length === 0) return 0;

  let streak = 0;
  let startDaysAgo = 0;
  const todayStr = getTodayStr();

  // Check if today has any completions
  const todayDone = completions.some(c => c.userId === userId && c.date === todayStr && c.completed);
  if (!todayDone) startDaysAgo = 1;

  for (let i = startDaysAgo; i < 365; i++) {
    const dateStr = getDateStr(i);
    const dayCompletions = completions.filter(c => c.userId === userId && c.date === dateStr && c.completed);
    if (dayCompletions.length > 0) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

// --- Default Suggestions ---

export const DEFAULT_SUGGESTIONS: HabitSuggestion[] = [
  {
    id: 'default-1', userId: 'system', userName: 'Habit Tracker',
    title: 'Morning Run', description: 'Start your day with a 20-30 min jog to boost energy, improve cardiovascular health, and elevate your mood.',
    category: 'Fitness', target: 'Run 30 minutes', recommendation: 'Best before breakfast',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-2', userId: 'system', userName: 'Habit Tracker',
    title: 'Drink 8 Glasses of Water', description: 'Staying hydrated keeps your body functioning optimally, improves skin health, and helps concentration.',
    category: 'Hydration', target: '8 glasses (2L)', recommendation: 'Keep a water bottle nearby',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-3', userId: 'system', userName: 'Habit Tracker',
    title: 'Read 20 Pages', description: 'Daily reading expands knowledge, reduces stress, and improves cognitive function.',
    category: 'Study', target: '20 pages per day', recommendation: 'Before bedtime works great',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-4', userId: 'system', userName: 'Habit Tracker',
    title: 'Sleep by 10 PM', description: 'Consistent sleep schedule regulates your circadian rhythm and improves sleep quality.',
    category: 'Sleep', target: 'In bed by 10 PM', recommendation: 'Avoid screens 1hr before',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-5', userId: 'system', userName: 'Habit Tracker',
    title: 'Eat 5 Servings of Vegetables', description: 'A plant-rich diet lowers disease risk and provides essential vitamins and minerals.',
    category: 'Healthy Eating', target: '5 servings of vegetables', recommendation: 'Add greens to every meal',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-6', userId: 'system', userName: 'Habit Tracker',
    title: '10-Minute Meditation', description: 'Short daily meditation reduces anxiety, improves focus, and supports emotional resilience.',
    category: 'Personal Development', target: '10 minutes of mindfulness', recommendation: 'Try a guided app session',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-7', userId: 'system', userName: 'Habit Tracker',
    title: 'Deep Work Session', description: 'Block 2 hours for focused, distraction-free work to maximize productivity.',
    category: 'Productivity', target: '2 hours deep work', recommendation: 'Morning hours are most effective',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
  {
    id: 'default-8', userId: 'system', userName: 'Habit Tracker',
    title: 'Evening Walk', description: 'A gentle 20-minute walk after dinner aids digestion and provides light physical activity.',
    category: 'Fitness', target: 'Walk 20 minutes', recommendation: 'After dinner',
    createdAt: '2024-01-01T00:00:00Z', status: 'approved', isDefault: true,
  },
];

// --- LocalStorage Keys ---

const KEYS = {
  users: 'ht_users',
  habits: 'ht_habits',
  completions: 'ht_completions',
  suggestions: 'ht_suggestions',
  settings: 'ht_settings',
  currentUserId: 'ht_current_user',
};

function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

// --- App State Shape ---

export interface AppState {
  screen: Screen;
  currentUser: User | null;
  users: User[];
  habits: Habit[];
  completions: HabitCompletion[];
  suggestions: HabitSuggestion[];
  settings: AppSettings;
  toasts: ToastMessage[];
  editingHabit: Habit | null;
}

// --- Context ---

export interface AppContextValue extends AppState {
  navigate: (screen: Screen) => void;
  login: (email: string, password: string) => string | null;
  signup: (name: string, email: string, password: string, userType: import('./types').UserType) => string | null;
  logout: () => void;
  createHabit: (data: Omit<Habit, 'id' | 'userId' | 'createdAt' | 'active'>) => void;
  updateHabit: (id: string, data: Partial<Habit>) => void;
  deleteHabit: (id: string) => void;
  completeHabit: (habitId: string, date: string) => boolean;
  addSuggestion: (data: Omit<HabitSuggestion, 'id' | 'userId' | 'userName' | 'createdAt' | 'status' | 'isDefault'>) => void;
  updateSettings: (data: Partial<AppSettings>) => void;
  updateUser: (id: string, data: Partial<User>) => void;
  showToast: (message: string, type?: ToastMessage['type']) => void;
  dismissToast: (id: string) => void;
  setEditingHabit: (habit: Habit | null) => void;
}

export const AppContext = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

// --- Initial State Loader ---

export function loadInitialState(): AppState {
  const currentUserId = localStorage.getItem(KEYS.currentUserId);
  const users = load<User[]>(KEYS.users, []);
  const habits = load<Habit[]>(KEYS.habits, []);
  const completions = load<HabitCompletion[]>(KEYS.completions, []);
  const storedSuggestions = load<HabitSuggestion[]>(KEYS.suggestions, []);
  const settings = load<AppSettings>(KEYS.settings, {
    theme: 'system', notificationsEnabled: true, remindersEnabled: true,
    privacy: 'public', language: 'en',
  });
  settings.privacy ??= 'public';
  settings.language ??= 'en';

  const currentUser = users.find(u => u.id === currentUserId) || null;

  // Merge default suggestions (add any missing ones)
  const existingDefaultIds = new Set(storedSuggestions.filter(s => s.isDefault).map(s => s.id));
  const missingDefaults = DEFAULT_SUGGESTIONS.filter(s => !existingDefaultIds.has(s.id));
  const suggestions = [...missingDefaults, ...storedSuggestions];

  return {
    screen: currentUser ? 'home' : 'splash',
    currentUser,
    users,
    habits,
    completions,
    suggestions,
    settings,
    toasts: [],
    editingHabit: null,
  };
}

// --- State Persistence Helpers ---

export function persistUsers(users: User[]): void { save(KEYS.users, users); }
export function persistHabits(habits: Habit[]): void { save(KEYS.habits, habits); }
export function persistCompletions(completions: HabitCompletion[]): void { save(KEYS.completions, completions); }
export function persistSuggestions(suggestions: HabitSuggestion[]): void { save(KEYS.suggestions, suggestions.filter(s => !s.isDefault)); }
export function persistSettings(settings: AppSettings): void { save(KEYS.settings, settings); }
export function persistCurrentUser(id: string | null): void {
  if (id) localStorage.setItem(KEYS.currentUserId, id);
  else localStorage.removeItem(KEYS.currentUserId);
}

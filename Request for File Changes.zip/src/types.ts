export type Screen =
  | 'splash'
  | 'landing'
  | 'login'
  | 'signup'
  | 'home'
  | 'habits'
  | 'calendar'
  | 'progress'
  | 'history'
  | 'search'
  | 'profile'
  | 'settings'
  | 'suggestions'
  | 'admin';

export type UserType =
  | 'Student'
  | 'Fitness Enthusiast'
  | 'Working Professional'
  | 'Senior/Elder'
  | 'General User'
  | 'Other';

export type HabitCategory =
  | 'Fitness'
  | 'Healthy Eating'
  | 'Sleep'
  | 'Hydration'
  | 'Study'
  | 'Productivity'
  | 'Personal Development'
  | 'Other';

export type HabitFrequency = 'Daily' | 'Weekly' | 'Custom';

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  userType: UserType;
  profileImage?: string;
  username?: string;
  bio?: string;
  isAdmin: boolean;
  createdAt: string;
}

export interface Habit {
  id: string;
  userId: string;
  name: string;
  description: string;
  category: HabitCategory;
  frequency: HabitFrequency;
  startDate: string;
  target: string;
  reminderEnabled: boolean;
  reminderTime: string;
  active: boolean;
  createdAt: string;
}

export interface HabitCompletion {
  id: string;
  userId: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  completed: boolean;
  completedAt: string;
}

export interface HabitSuggestion {
  id: string;
  userId: string;
  userName: string;
  title: string;
  description: string;
  category: HabitCategory;
  target?: string;
  recommendation?: string;
  createdAt: string;
  status: 'pending' | 'approved';
  isDefault?: boolean;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  notificationsEnabled: boolean;
  remindersEnabled: boolean;
  privacy: 'public' | 'private';
  language: 'en' | 'es' | 'fr';
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export const HABIT_CATEGORIES: HabitCategory[] = [
  'Fitness', 'Healthy Eating', 'Sleep', 'Hydration',
  'Study', 'Productivity', 'Personal Development', 'Other',
];

export const USER_TYPES: UserType[] = [
  'Student', 'Fitness Enthusiast', 'Working Professional',
  'Senior/Elder', 'General User', 'Other',
];

export const CATEGORY_ICONS: Record<HabitCategory, string> = {
  'Fitness': '🏃',
  'Healthy Eating': '🥗',
  'Sleep': '😴',
  'Hydration': '💧',
  'Study': '📚',
  'Productivity': '⚡',
  'Personal Development': '🌱',
  'Other': '✨',
};

export const CATEGORY_COLORS: Record<HabitCategory, string> = {
  'Fitness': '#E8602C',
  'Healthy Eating': '#3D8B4E',
  'Sleep': '#6B7FF0',
  'Hydration': '#2D9D92',
  'Study': '#D4821A',
  'Productivity': '#9B59B6',
  'Personal Development': '#27AE60',
  'Other': '#95A5A6',
};
